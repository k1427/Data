package com.examly.springapp.service;

import com.examly.springapp.model.InstructionalVideo;
import com.examly.springapp.repository.InstructionalVideoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InstructionVideoServiceImpl implements InstructionalVideoService {

    @Autowired
    private InstructionalVideoRepository instructionalVideoRepository;

    @Override
    public InstructionalVideo createInstructionalVideo(InstructionalVideo video) {
        return instructionalVideoRepository.save(video);
    }

    @Override
    public Optional<InstructionalVideo> getInstructionalVideoById(Long id) {
        return instructionalVideoRepository.findById(id);
    }

    @Override
    public List<InstructionalVideo> getAllInstructionalVideos() {
        return instructionalVideoRepository.findAll();
    }

    @Override
    public Optional<InstructionalVideo> updateInstructionalVideo(Long id, InstructionalVideo video) {
        if (instructionalVideoRepository.existsById(id)) {
            video.setId(id);
            return Optional.of(instructionalVideoRepository.save(video));
        }
        return Optional.empty();
    }

    @Override
    public boolean deleteInstructionalVideo(Long id) {
        if (instructionalVideoRepository.existsById(id)) {
            instructionalVideoRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
