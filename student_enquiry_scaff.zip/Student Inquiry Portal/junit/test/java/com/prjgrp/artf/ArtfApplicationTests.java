package com.prjgrp.artf;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.prjgrp.artf.controller.FaqController;
import com.prjgrp.artf.controller.UserController;
import com.prjgrp.artf.model.Faq;
import com.prjgrp.artf.model.User;
import com.prjgrp.artf.service.FaqService;
import com.prjgrp.artf.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.Collections;

@WebMvcTest({FaqController.class, UserController.class})
public class ArtfApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private FaqService faqService;

    @MockBean
    private UserService userService;

    // FAQ Tests
    @Test
    public void testCreateFAQ() throws Exception {
        Faq faq = new Faq(1L, "Question?", "Answer?");
        Mockito.when(faqService.createFaq(any(Faq.class))).thenReturn(faq);

        mockMvc.perform(post("/faqs")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(faq)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.question").value("Question?"))
                .andExpect(jsonPath("$.answer").value("Answer?"));
    }

    @Test
    public void testGetFAQById() throws Exception {
        Faq faq = new Faq(1L, "Question?", "Answer?");
        Mockito.when(faqService.getFaqById(anyLong())).thenReturn(faq);

        mockMvc.perform(get("/faqs/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.question").value("Question?"))
                .andExpect(jsonPath("$.answer").value("Answer?"));
    }

    @Test
    public void testGetAllFAQs() throws Exception {
        Faq faq = new Faq(1L, "Question?", "Answer?");
        Mockito.when(faqService.getAllFaqs()).thenReturn(Collections.singletonList(faq));

        mockMvc.perform(get("/faqs"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].question").value("Question?"))
                .andExpect(jsonPath("$[0].answer").value("Answer?"));
    }

    @Test
    public void testUpdateFAQ() throws Exception {
        Faq faq = new Faq(1L, "Updated Question?", "Updated Answer?");
        Mockito.when(faqService.updateFaq(anyLong(), any(Faq.class))).thenReturn(faq);

        mockMvc.perform(put("/faqs/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(faq)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.question").value("Updated Question?"))
                .andExpect(jsonPath("$.answer").value("Updated Answer?"));
    }

    @Test
    public void testDeleteFAQ() throws Exception {
        Mockito.doNothing().when(faqService).deleteFaq(anyLong());

        mockMvc.perform(delete("/faqs/1"))
                .andExpect(status().isNoContent());
    }

    // User Tests
    @Test
    public void testCreateUser() throws Exception {
        User user = new User(1L, "username", "user@example.com");
        Mockito.when(userService.createUser(any(User.class))).thenReturn(user);

        mockMvc.perform(post("/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(user)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("username"))
                .andExpect(jsonPath("$.email").value("user@example.com"));
    }

    @Test
    public void testGetUserById() throws Exception {
        User user = new User(1L, "username", "user@example.com");
        Mockito.when(userService.getUserById(anyLong())).thenReturn(user);

        mockMvc.perform(get("/users/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("username"))
                .andExpect(jsonPath("$.email").value("user@example.com"));
    }

    @Test
    public void testGetAllUsers() throws Exception {
        User user = new User(1L, "username", "user@example.com");
        Mockito.when(userService.getAllUsers()).thenReturn(Collections.singletonList(user));

        mockMvc.perform(get("/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].username").value("username"))
                .andExpect(jsonPath("$[0].email").value("user@example.com"));
    }

    @Test
    public void testUpdateUser() throws Exception {
        User user = new User(1L, "updatedUser", "updated@example.com");
        Mockito.when(userService.updateUser(anyLong(), any(User.class))).thenReturn(user);

        mockMvc.perform(put("/users/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(user)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("updatedUser"))
                .andExpect(jsonPath("$.email").value("updated@example.com"));
    }

    @Test
    public void testDeleteUser() throws Exception {
        Mockito.doNothing().when(userService).deleteUser(anyLong());

        mockMvc.perform(delete("/users/1"))
                .andExpect(status().isNoContent());
    }
}
