package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.examly.springapp.model.InstructionalVideo;
import com.examly.springapp.service.InstructionalVideoService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/videos")
public class InstructionalVideoController {

    @Autowired
    private InstructionalVideoService instructionalVideoService;

    @PostMapping
    public ResponseEntity<InstructionalVideo> createInstructionalVideo(@RequestBody InstructionalVideo video) {
        InstructionalVideo createdVideo = instructionalVideoService.createInstructionalVideo(video);
        return ResponseEntity.status(201).body(createdVideo);
    }

    @GetMapping("/{id}")
    public ResponseEntity<InstructionalVideo> getInstructionalVideoById(@PathVariable Long id) {
        Optional<InstructionalVideo> video = instructionalVideoService.getInstructionalVideoById(id);
        return video.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.status(404).build());
    }

    @GetMapping
    public ResponseEntity<List<InstructionalVideo>> getAllInstructionalVideos() {
        List<InstructionalVideo> videos = instructionalVideoService.getAllInstructionalVideos();
        return ResponseEntity.ok(videos);
    }

    @PutMapping("/{id}")
    public ResponseEntity<InstructionalVideo> updateInstructionalVideo(@PathVariable Long id, @RequestBody InstructionalVideo video) {
        Optional<InstructionalVideo> updatedVideo = instructionalVideoService.updateInstructionalVideo(id, video);
        return updatedVideo.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.status(404).build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInstructionalVideo(@PathVariable Long id) {
        if (instructionalVideoService.deleteInstructionalVideo(id)) {
            return ResponseEntity.status(204).build();
        } else {
            return ResponseEntity.status(404).build();
        }
    }
}
