package com.examly.springapp.service;

import com.examly.springapp.model.YogaClass;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
@Service
public interface YogaClassService {
    YogaClass createYogaClass(YogaClass yogaClass);
    Optional<YogaClass> getYogaClassById(Long id);
    List<YogaClass> getAllYogaClasses();
    Optional<YogaClass> updateYogaClass(Long id, YogaClass yogaClass);
    boolean deleteYogaClass(Long id);
}
