package com.examly.springapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.YogaClass;
import com.examly.springapp.repository.YogaClassRepository;

import java.util.List;
import java.util.Optional;

@Service
public class YogaClassServiceImpl implements YogaClassService {

    @Autowired
    private YogaClassRepository yogaClassRepository;

    @Override
    public YogaClass createYogaClass(YogaClass yogaClass) {
        return yogaClassRepository.save(yogaClass);
    }

    @Override
    public Optional<YogaClass> getYogaClassById(Long id) {
        return yogaClassRepository.findById(id);
    }

    @Override
    public List<YogaClass> getAllYogaClasses() {
        return yogaClassRepository.findAll();
    }

    @Override
    public Optional<YogaClass> updateYogaClass(Long id, YogaClass yogaClass) {
        if (yogaClassRepository.existsById(id)) {
            yogaClass.setId(id);  // Ensure ID is set for update
            return Optional.of(yogaClassRepository.save(yogaClass));
        } else {
            return Optional.empty();
        }
    }

    @Override
    public boolean deleteYogaClass(Long id) {
        if (yogaClassRepository.existsById(id)) {
            yogaClassRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }
}
