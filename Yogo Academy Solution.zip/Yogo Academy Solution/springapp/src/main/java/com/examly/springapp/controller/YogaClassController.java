package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.examly.springapp.model.YogaClass;
import com.examly.springapp.service.YogaClassService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/classes")
public class YogaClassController {

    @Autowired
    private YogaClassService yogaClassService;

    @PostMapping
    public ResponseEntity<YogaClass> createYogaClass(@RequestBody YogaClass yogaClass) {
        YogaClass createdClass = yogaClassService.createYogaClass(yogaClass);
        return ResponseEntity.status(201).body(createdClass);
    }

    @GetMapping("/{id}")
    public ResponseEntity<YogaClass> getYogaClassById(@PathVariable Long id) {
        Optional<YogaClass> yogaClass = yogaClassService.getYogaClassById(id);
        return yogaClass.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.status(404).build());
    }

    @GetMapping
    public ResponseEntity<List<YogaClass>> getAllYogaClasses() {
        List<YogaClass> classes = yogaClassService.getAllYogaClasses();
        return ResponseEntity.ok(classes);
    }

    @PutMapping("/{id}")
    public ResponseEntity<YogaClass> updateYogaClass(@PathVariable Long id, @RequestBody YogaClass yogaClass) {
        Optional<YogaClass> updatedClass = yogaClassService.updateYogaClass(id, yogaClass);
        return updatedClass.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.status(404).build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteYogaClass(@PathVariable Long id) {
        if (yogaClassService.deleteYogaClass(id)) {
            return ResponseEntity.status(204).build();
        } else {
            return ResponseEntity.status(404).build();
        }
    }
}
