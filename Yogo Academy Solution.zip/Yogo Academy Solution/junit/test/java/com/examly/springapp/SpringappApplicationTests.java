package com.examly.springapp;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.examly.springapp.model.User;
import com.examly.springapp.model.YogaClass;
import com.examly.springapp.controller.InstructionalVideoController;
import com.examly.springapp.controller.UserController;
import com.examly.springapp.controller.YogaClassController;
import com.examly.springapp.model.InstructionalVideo;
import com.examly.springapp.service.UserService;
import com.examly.springapp.service.YogaClassService;
import com.examly.springapp.service.InstructionalVideoService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Optional;

@WebMvcTest({YogaClassController.class, UserController.class, InstructionalVideoController.class})
public class SpringappApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private YogaClassService yogaClassService;

    @MockBean
    private UserService userService;

    @MockBean
    private InstructionalVideoService instructionalVideoService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // YogaClassController Tests

    @Test
    void testCreateYogaClass() throws Exception {
        YogaClass yogaClass = new YogaClass();
        yogaClass.setId(1L);
        yogaClass.setName("Hatha Yoga");
        yogaClass.setDescription("A gentle introduction to yoga.");

        when(yogaClassService.createYogaClass(any(YogaClass.class))).thenReturn(yogaClass);

        mockMvc.perform(post("/api/classes")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\": \"Hatha Yoga\", \"description\": \"A gentle introduction to yoga.\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.name").value("Hatha Yoga"))
                .andExpect(jsonPath("$.description").value("A gentle introduction to yoga."));
    }

    @Test
    void testGetYogaClassById() throws Exception {
        YogaClass yogaClass = new YogaClass();
        yogaClass.setId(1L);
        yogaClass.setName("Hatha Yoga");
        yogaClass.setDescription("A gentle introduction to yoga.");

        when(yogaClassService.getYogaClassById(anyLong())).thenReturn(Optional.of(yogaClass));

        mockMvc.perform(get("/api/classes/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.name").value("Hatha Yoga"))
                .andExpect(jsonPath("$.description").value("A gentle introduction to yoga."));
    }

    @Test
    void testGetYogaClassByIdNotFound() throws Exception {
        when(yogaClassService.getYogaClassById(anyLong())).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/classes/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    void testGetAllYogaClasses() throws Exception {
        YogaClass yogaClass1 = new YogaClass();
        yogaClass1.setId(1L);
        yogaClass1.setName("Hatha Yoga");
        yogaClass1.setDescription("A gentle introduction to yoga.");

        YogaClass yogaClass2 = new YogaClass();
        yogaClass2.setId(2L);
        yogaClass2.setName("Vinyasa Yoga");
        yogaClass2.setDescription("A flowing style of yoga.");

        when(yogaClassService.getAllYogaClasses()).thenReturn(Arrays.asList(yogaClass1, yogaClass2));

        mockMvc.perform(get("/api/classes")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].name").value("Hatha Yoga"))
                .andExpect(jsonPath("$[0].description").value("A gentle introduction to yoga."))
                .andExpect(jsonPath("$[1].id").value(2))
                .andExpect(jsonPath("$[1].name").value("Vinyasa Yoga"))
                .andExpect(jsonPath("$[1].description").value("A flowing style of yoga."));
    }

    @Test
    void testUpdateYogaClass() throws Exception {
        YogaClass yogaClass = new YogaClass();
        yogaClass.setId(1L);
        yogaClass.setName("Hatha Yoga");
        yogaClass.setDescription("A gentle introduction to yoga.");

        YogaClass updatedYogaClass = new YogaClass();
        updatedYogaClass.setId(1L);
        updatedYogaClass.setName("Advanced Hatha Yoga");
        updatedYogaClass.setDescription("An advanced level of Hatha Yoga.");

        when(yogaClassService.updateYogaClass(anyLong(), any(YogaClass.class))).thenReturn(Optional.of(updatedYogaClass));

        mockMvc.perform(put("/api/classes/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\": \"Advanced Hatha Yoga\", \"description\": \"An advanced level of Hatha Yoga.\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.name").value("Advanced Hatha Yoga"))
                .andExpect(jsonPath("$.description").value("An advanced level of Hatha Yoga."));
    }

    @Test
    void testUpdateYogaClassNotFound() throws Exception {
        when(yogaClassService.updateYogaClass(anyLong(), any(YogaClass.class))).thenReturn(Optional.empty());

        mockMvc.perform(put("/api/classes/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\": \"Advanced Hatha Yoga\", \"description\": \"An advanced level of Hatha Yoga.\"}"))
                .andExpect(status().isNotFound());
    }

    @Test
    void testDeleteYogaClass() throws Exception {
        when(yogaClassService.deleteYogaClass(anyLong())).thenReturn(true);

        mockMvc.perform(delete("/api/classes/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }

    @Test
    void testDeleteYogaClassNotFound() throws Exception {
        when(yogaClassService.deleteYogaClass(anyLong())).thenReturn(false);

        mockMvc.perform(delete("/api/classes/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    // UserController Tests

    @Test
    void testCreateUser() throws Exception {
        User user = new User();
        user.setId(1L);
        user.setUsername("John Doe");
        user.setEmail("john.doe@example.com");

        when(userService.createUser(any(User.class))).thenReturn(user);

        mockMvc.perform(post("/api/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\": \"John Doe\", \"email\": \"john.doe@example.com\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("John Doe"))
                .andExpect(jsonPath("$.email").value("john.doe@example.com"));
    }

    @Test
    void testGetUserById() throws Exception {
        User user = new User();
        user.setId(1L);
        user.setUsername("John Doe");
        user.setEmail("john.doe@example.com");

        when(userService.getUserById(anyLong())).thenReturn(Optional.of(user));

        mockMvc.perform(get("/api/users/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("John Doe"))
                .andExpect(jsonPath("$.email").value("john.doe@example.com"));
    }

    @Test
    void testGetUserByIdNotFound() throws Exception {
        when(userService.getUserById(anyLong())).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/users/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    void testGetAllUsers() throws Exception {
        User user1 = new User();
        user1.setId(1L);
        user1.setUsername("John Doe");
        user1.setEmail("john.doe@example.com");

        User user2 = new User();
        user2.setId(2L);
        user2.setUsername("Jane Doe");
        user2.setEmail("jane.doe@example.com");

        when(userService.getAllUsers()).thenReturn(Arrays.asList(user1, user2));

        mockMvc.perform(get("/api/users")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].username").value("John Doe"))
                .andExpect(jsonPath("$[0].email").value("john.doe@example.com"))
                .andExpect(jsonPath("$[1].id").value(2))
                .andExpect(jsonPath("$[1].username").value("Jane Doe"))
                .andExpect(jsonPath("$[1].email").value("jane.doe@example.com"));
    }

    @Test
    void testUpdateUser() throws Exception {
        User user = new User();
        user.setId(1L);
        user.setUsername("John Doe");
        user.setEmail("john.doe@example.com");

        User updatedUser = new User();
        updatedUser.setId(1L);
        updatedUser.setUsername("John Smith");
        updatedUser.setEmail("john.smith@example.com");

        when(userService.updateUser(anyLong(), any(User.class))).thenReturn(Optional.of(updatedUser));

        mockMvc.perform(put("/api/users/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\": \"John Smith\", \"email\": \"john.smith@example.com\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("John Smith"))
                .andExpect(jsonPath("$.email").value("john.smith@example.com"));
    }

    @Test
    void testUpdateUserNotFound() throws Exception {
        when(userService.updateUser(anyLong(), any(User.class))).thenReturn(Optional.empty());

        mockMvc.perform(put("/api/users/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\": \"John Smith\", \"email\": \"john.smith@example.com\"}"))
                .andExpect(status().isNotFound());
    }

    @Test
    void testDeleteUser() throws Exception {
        when(userService.deleteUser(anyLong())).thenReturn(true);

        mockMvc.perform(delete("/api/users/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }

    @Test
    void testDeleteUserNotFound() throws Exception {
        when(userService.deleteUser(anyLong())).thenReturn(false);

        mockMvc.perform(delete("/api/users/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    // InstructionalVideoController Tests

    @Test
    void testCreateInstructionalVideo() throws Exception {
        InstructionalVideo video = new InstructionalVideo();
        video.setId(1L);
        video.setTitle("Yoga for Beginners");
        video.setUrl("http://example.com/video");

        when(instructionalVideoService.createInstructionalVideo(any(InstructionalVideo.class))).thenReturn(video);

        mockMvc.perform(post("/api/videos")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"title\": \"Yoga for Beginners\", \"url\": \"http://example.com/video\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.title").value("Yoga for Beginners"))
                .andExpect(jsonPath("$.url").value("http://example.com/video"));
    }

    @Test
    void testGetInstructionalVideoById() throws Exception {
        InstructionalVideo video = new InstructionalVideo();
        video.setId(1L);
        video.setTitle("Yoga for Beginners");
        video.setUrl("http://example.com/video");

        when(instructionalVideoService.getInstructionalVideoById(anyLong())).thenReturn(Optional.of(video));

        mockMvc.perform(get("/api/videos/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.title").value("Yoga for Beginners"))
                .andExpect(jsonPath("$.url").value("http://example.com/video"));
    }

    @Test
    void testGetInstructionalVideoByIdNotFound() throws Exception {
        when(instructionalVideoService.getInstructionalVideoById(anyLong())).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/videos/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    void testGetAllInstructionalVideos() throws Exception {
        InstructionalVideo video1 = new InstructionalVideo();
        video1.setId(1L);
        video1.setTitle("Yoga for Beginners");
        video1.setUrl("http://example.com/video");

        InstructionalVideo video2 = new InstructionalVideo();
        video2.setId(2L);
        video2.setTitle("Advanced Yoga");
        video2.setUrl("http://example.com/video2");

        when(instructionalVideoService.getAllInstructionalVideos()).thenReturn(Arrays.asList(video1, video2));

        mockMvc.perform(get("/api/videos")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].title").value("Yoga for Beginners"))
                .andExpect(jsonPath("$[0].url").value("http://example.com/video"))
                .andExpect(jsonPath("$[1].id").value(2))
                .andExpect(jsonPath("$[1].title").value("Advanced Yoga"))
                .andExpect(jsonPath("$[1].url").value("http://example.com/video2"));
    }

    @Test
    void testUpdateInstructionalVideo() throws Exception {
        InstructionalVideo video = new InstructionalVideo();
        video.setId(1L);
        video.setTitle("Yoga for Beginners");
        video.setUrl("http://example.com/video");

        InstructionalVideo updatedVideo = new InstructionalVideo();
        updatedVideo.setId(1L);
        updatedVideo.setTitle("Yoga for Advanced Users");
        updatedVideo.setUrl("http://example.com/video-updated");

        when(instructionalVideoService.updateInstructionalVideo(anyLong(), any(InstructionalVideo.class))).thenReturn(Optional.of(updatedVideo));

        mockMvc.perform(put("/api/videos/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"title\": \"Yoga for Advanced Users\", \"url\": \"http://example.com/video-updated\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.title").value("Yoga for Advanced Users"))
                .andExpect(jsonPath("$.url").value("http://example.com/video-updated"));
    }

    @Test
    void testUpdateInstructionalVideoNotFound() throws Exception {
        when(instructionalVideoService.updateInstructionalVideo(anyLong(), any(InstructionalVideo.class))).thenReturn(Optional.empty());

        mockMvc.perform(put("/api/videos/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"title\": \"Yoga for Advanced Users\", \"url\": \"http://example.com/video-updated\"}"))
                .andExpect(status().isNotFound());
    }

    @Test
    void testDeleteInstructionalVideo() throws Exception {
        when(instructionalVideoService.deleteInstructionalVideo(anyLong())).thenReturn(true);

        mockMvc.perform(delete("/api/videos/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }

    @Test
    void testDeleteInstructionalVideoNotFound() throws Exception {
        when(instructionalVideoService.deleteInstructionalVideo(anyLong())).thenReturn(false);

        mockMvc.perform(delete("/api/videos/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }
}
