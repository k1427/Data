package com.prjgrp.artf.model;

public class Tag {
    
}
