package com.prjgrp.artf.repository;

public class TagRepository {
    
}
