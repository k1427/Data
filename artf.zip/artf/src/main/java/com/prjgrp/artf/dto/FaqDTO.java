// package com.prjgrp.artf.dto;

// import jakarta.validation.constraints.NotBlank;
// import jakarta.validation.constraints.Size;

// public class FaqDTO {

//     @NotBlank(message = "Question is required")
//     @Size(max = 255, message = "Question must be less than or equal to 255 characters")
//     private String question;

//     @NotBlank(message = "Answer is required")
//     @Size(max = 500, message = "Answer must be less than or equal to 500 characters")
//     private String answer;

//     // Default constructor
//     public FaqDTO() {
//     }

//     // Parameterized constructor
//     public FaqDTO(String question, String answer) {
//         this.question = question;
//         this.answer = answer;
//     }

//     // Getters and Setters
//     public String getQuestion() {
//         return question;
//     }

//     public void setQuestion(String question) {
//         this.question = question;
//     }

//     public String getAnswer() {
//         return answer;
//     }

//     public void setAnswer(String answer) {
//         this.answer = answer;
//     }
// }
