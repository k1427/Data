package com.prjgrp.artf.service;

import com.prjgrp.artf.model.Faq;
import com.prjgrp.artf.repository.FaqRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FaqService {
    private final FaqRepository faqRepository;

    public FaqService(FaqRepository faqRepository) {
        this.faqRepository = faqRepository;
    }

    public Faq createFaq(Faq faq) {
        return faqRepository.save(faq);
    }

    public Faq getFaqById(Long id) {
        return faqRepository.findById(id).orElse(null);
    }

    public List<Faq> getAllFaqs() {
        return faqRepository.findAll();
    }

    public Faq updateFaq(Long id, Faq faq) {
        if (faqRepository.existsById(id)) {
            faq.setId(id);
            return faqRepository.save(faq);
        }
        return null;
    }

    public void deleteFaq(Long id) {
        faqRepository.deleteById(id);
    }
}
