package com.prjgrp.artf.controller;

import com.prjgrp.artf.model.Faq;
import com.prjgrp.artf.service.FaqService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/faqs")
public class FaqController {
    private final FaqService faqService;

    public FaqController(FaqService faqService) {
        this.faqService = faqService;
    }

    @PostMapping
    public ResponseEntity<Faq> createFAQ(@RequestBody Faq faq) {
        Faq createdFaq = faqService.createFaq(faq);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdFaq);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Faq> getFAQById(@PathVariable Long id) {
        Faq faq = faqService.getFaqById(id);
        return faq != null ? ResponseEntity.ok(faq) : ResponseEntity.notFound().build();
    }

    @GetMapping
    public ResponseEntity<List<Faq>> getAllFAQs() {
        List<Faq> faqs = faqService.getAllFaqs();
        return ResponseEntity.ok(faqs);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Faq> updateFAQ(@PathVariable Long id, @RequestBody Faq faq) {
        Faq updatedFaq = faqService.updateFaq(id, faq);
        return updatedFaq != null ? ResponseEntity.ok(updatedFaq) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFAQ(@PathVariable Long id) {
        faqService.deleteFaq(id);
        return ResponseEntity.noContent().build();
    }
}
