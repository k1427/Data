package com.prjgrp.artf.model;

public class Category {
    
}
