// src/components/RepairGuides/RepairGuides.js
import React, { useState } from 'react';
import './RepairGuides.css';

const RepairGuides = () => {
  const [showDetails, setShowDetails] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);

  const repairGuides = [
    { id: 1, title: 'Engine Repair', details: 'Engine repair details.' },
    { id: 2, title: 'Brake Repair', details: 'Brake repair details.' },
  ];

  const handleViewDetails = () => setShowDetails(true);
  const handleAddGuide = () => setShowForm(true);

  const handleFormSubmit = (e) => {
    e.preventDefault();
    setShowForm(false); // Hide form immediately
    setTimeout(() => setShowSuccessMessage(true), 500); // Display success message after 500ms
  };

  return (
    <div className="repair-guides">
      <h2>Repair Guides</h2>
      <ul>
        {repairGuides.map((guide) => (
          <li key={guide.id}>
            <h3>{guide.title}</h3>
            <button onClick={handleViewDetails}>View Details</button>
            {showDetails && <p>{guide.details}</p>}
          </li>
        ))}
      </ul>
      <button onClick={handleAddGuide}>Add Repair Guide</button>

      {showForm && (
        <form onSubmit={handleFormSubmit}>
          <label htmlFor="title">Title:</label>
          <input id="title" type="text" />
          <label htmlFor="description">Description:</label>
          <input id="description" type="text" />
          <button type="submit">Submit Repair Guide</button>
        </form>
      )}

      {showSuccessMessage && <p>Repair Guide added successfully!</p>}
    </div>
  );
};

export default RepairGuides;
