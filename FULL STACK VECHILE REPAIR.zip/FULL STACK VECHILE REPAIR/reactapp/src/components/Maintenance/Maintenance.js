// src/components/Maintenance/Maintenance.js
import React, { useState } from 'react';
import './Maintenance.css';

const Maintenance = () => {
  const [showForm, setShowForm] = useState(false);

  const maintenanceTasks = [
    { id: 1, title: 'Engine Oil Change', details: 'Details about engine oil change.' },
    { id: 2, title: 'Brake Pad Replacement', details: 'Details about brake pad replacement.' },
  ];

  const handleAddTask = () => setShowForm(true);

  return (
    <div className="maintenance">
      
      <ul>
        {maintenanceTasks.map((task) => (
          <li key={task.id}>
            <h3>{task.title}</h3>
            <p>{task.details}</p>
          </li>
        ))}
      </ul>
      <button onClick={handleAddTask}>Add Maintenance Task</button>

      {showForm && (
        <form>
          <label htmlFor="title">Title:</label>
          <input id="title" type="text" />
          <label htmlFor="description">Description:</label>
          <input id="description" type="text" />
          <button type="submit">Submit Maintenance Task</button>
        </form>
      )}
    </div>
  );
};

export default Maintenance;
