// src/components/Forum/Forum.js
import React, { useState } from 'react';
import './Forum.css';

const Forum = () => {
  const [showDetails, setShowDetails] = useState(false);
  const [showForm, setShowForm] = useState(false);

  const forumPosts = [
    { id: 1, title: 'Brakes Issue', details: 'Details about brakes issue.' },
    { id: 2, title: 'Engine Overheating', details: 'Engine overheating details.' },
  ];

  const handleViewPost = () => setShowDetails(true);
  const handleAddPost = () => setShowForm(true);

  return (
    <div className="forum">
      
      <ul>
        {forumPosts.map((post) => (
          <li key={post.id}>
            <h3>{post.title}</h3>
            <button onClick={handleViewPost}>View Post</button>
            {showDetails && <p>{post.details}</p>}
          </li>
        ))}
      </ul>
      <button onClick={handleAddPost}>Add Forum Post</button>

      {showForm && (
        <form>
          <label htmlFor="title">Title:</label>
          <input id="title" type="text" />
          <label htmlFor="details">Details:</label>
          <input id="details" type="text" />
          <button type="submit">Submit Post</button>
        </form>
      )}
    </div>
  );
};

export default Forum;
