// src/components/Diagnostic/Diagnostic.js
import React from 'react';
import './Diagnostic.css';

const Diagnostic = () => (
  <div className="diagnostic">
    <h2>Diagnostic Tools</h2>
    <form>
      <label htmlFor="issue">Issue:</label>
      <input id="issue" type="text" />
      <label htmlFor="description">Description:</label>
      <input id="description" type="text" />
      <button type="submit">Submit Diagnostic</button>
    </form>
  </div>
);

export default Diagnostic;
