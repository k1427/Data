// src/tests/App.test.js

import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import App from '../App';
import RepairGuides from '../components/RepairGuides/RepairGuides';
import Maintenance from '../components/Maintenance/Maintenance';
import Diagnostic from '../components/Diagnostic/Diagnostic';
import Forum from '../components/Forum/Forum';

describe('Vehicle Repair Hub App', () => {
  // 1. Test to check if 'Vehicle Repair Hub' title is present
  test('renders app heading correctly', async () => {
    render(<App />);
    const headingText = screen.getByText(/Vehicle Repair Hub/i);
    expect(headingText).toBeInTheDocument();
  });

  // 2. Test to check if 'Repair Guides' text is present in the RepairGuides component
  test('renders Repair Guides component correctly', async () => {
    render(<RepairGuides />);
    const repairGuidesText = screen.getByText(/Repair Guides/i);
    expect(repairGuidesText).toBeInTheDocument();
  });

  // 3. Test to check if 'Maintenance' text is present in the Maintenance component
  test('renders Maintenance component correctly', async () => {
    render(<Maintenance />);
    const maintenanceText = screen.getByText(/Maintenance/i);
    expect(maintenanceText).toBeInTheDocument();
  });

  // 4. Test to check if 'Diagnostic Tools' text is present in the Diagnostic component
  test('renders Diagnostic component correctly', async () => {
    render(<Diagnostic />);
    const diagnosticToolsText = screen.getByText(/Diagnostic Tools/i);
    expect(diagnosticToolsText).toBeInTheDocument();
  });

  // 5. Test to check if 'Forum' text is present in the Forum component
  test('renders Forum component correctly', async () => {
    render(<Forum />);
    const forumText = screen.getByText(/Forum/i);
    expect(forumText).toBeInTheDocument();
  });

  // 6. Test to check for details after clicking 'View Details' button in Repair Guides
  test('click View Details button in Repair Guides and check details', async () => {
    render(<RepairGuides />);

    const viewDetailsButtons = await screen.findAllByText(/View Details/i);
    fireEvent.click(viewDetailsButtons[0]); // Simulate clicking the first View Details button

    // Check if detailed information is displayed after clicking
    const detailText = await screen.findByText(/Engine repair details/i);
    expect(detailText).toBeInTheDocument();
  });

  // 7. Test to check 'Add Repair Guide' button functionality in Repair Guides
  test('click Add Repair Guide button and check form fields', async () => {
    render(<RepairGuides />);

    const addButton = await screen.findByRole('button', { name: /Add Repair Guide/i });
    fireEvent.click(addButton);

    await waitFor(() => {
      expect(screen.getByLabelText(/Title:/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/Description:/i)).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /Submit Repair Guide/i })).toBeInTheDocument();
    });
  });

  // 8. Test to check form submission in Repair Guides component
  test('submit Repair Guide form and show success message', async () => {
    render(<RepairGuides />);

    // First, click the "Add Repair Guide" button to display the form
    const addRepairGuideButton = screen.getByText(/Add Repair Guide/i);
    fireEvent.click(addRepairGuideButton);

    // Now that the form is visible, we can interact with the form fields
    fireEvent.change(screen.getByLabelText(/Title:/i), { target: { value: 'Engine Repair' } });
    fireEvent.change(screen.getByLabelText(/Description:/i), { target: { value: 'Details about engine repair' } });

    // Submit the form
    fireEvent.click(screen.getByRole('button', { name: /Submit Repair Guide/i }));

    // Check for the success message after form submission
    await waitFor(() => {
      expect(screen.getByText(/Repair Guide added successfully!/i)).toBeInTheDocument();
    });
  });

  // 9. Test to check 'Add Maintenance Task' functionality in Maintenance component
  test('click Add Maintenance Task button and check form fields', async () => {
    render(<Maintenance />);

    const addButton = await screen.findByRole('button', { name: /Add Maintenance Task/i });
    fireEvent.click(addButton);

    await waitFor(() => {
      expect(screen.getByLabelText(/Title:/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/Description:/i)).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /Submit Maintenance Task/i })).toBeInTheDocument();
    });
  });

  // 10. Test to check if all required labels are present in Diagnostic Tools form
  test('renders Diagnostic Tools form with required labels', () => {
    render(<Diagnostic />);

    const issueLabel = screen.getByText(/Issue:/i);
    const descriptionLabel = screen.getByText(/Description:/i);
    expect(issueLabel).toBeInTheDocument();
    expect(descriptionLabel).toBeInTheDocument();
  });

  // 11. Test to check 'Add Forum Post' button and form fields in Forum component
  test('click Add Forum Post button and check fields', async () => {
    render(<Forum />);

    const addButton = await screen.findByRole('button', { name: /Add Forum Post/i });
    fireEvent.click(addButton);

    await waitFor(() => {
      expect(screen.getByLabelText(/Title:/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/Details:/i)).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /Submit Post/i })).toBeInTheDocument();
    });
  });

  // 12. Test to check if Forum component displays post details after clicking 'View Post'
  test('click View Post button in Forum and show post details', async () => {
    render(<Forum />);

    const viewPostButtons = await screen.findAllByText(/View Post/i);
    fireEvent.click(viewPostButtons[0]); // Click the first View Post button

    const postDetailText = await screen.findByText(/Details about brakes issue/i);
    expect(postDetailText).toBeInTheDocument();
  });
});
