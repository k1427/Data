// src/App.js
import React from 'react';
import './App.css';
import RepairGuides from './components/RepairGuides/RepairGuides';
import Maintenance from './components/Maintenance/Maintenance';
import Diagnostic from './components/Diagnostic/Diagnostic';
import Forum from './components/Forum/Forum';

function App() {
  return (
    <div className="App">
      <h1>Vehicle Repair Hub</h1>
      <RepairGuides />
      <Maintenance />
      <Diagnostic />
      <Forum />
    </div>
  );
}

export default App;
