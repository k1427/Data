package com.prjgrp.artf.repository;

import com.prjgrp.artf.entity.RepairGuide;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepairGuideRepository extends JpaRepository<RepairGuide, Long> {
}
