// // package com.prjgrp.artf.model;

// // public class Course {
    
// // }


// package com.prjgrp.artf.entity;

// import jakarta.persistence.*;
// import lombok.*;

// @Entity
// @Data
// @NoArgsConstructor
// @AllArgsConstructor
// public class Course {
//     @Id
//     @GeneratedValue(strategy = GenerationType.IDENTITY)
//     private Long id;
//     private String name;
//     private String description;
// }


// // package com.prjgrp.artf.entity;

// // import jakarta.persistence.*;

// // import java.util.List;


// // @Entity
// // @Table(name = "courses")
// // public class Course {

// //     @Id
// //     @GeneratedValue(strategy = GenerationType.IDENTITY)
// //     private Long id;

    
// //     private String name;

// //     private String description;

// //     @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
// //     private List<Material> materials;

// //     @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
// //     private List<Enrollment> enrollments;

// //     // Constructors, Getters, and Setters

// //     public Course() {
// //     }

// //     public Course(Long id, String name, String description) {
// //         this.id = id;
// //         this.name = name;
// //         this.description = description;
// //     }

// //     public Long getId() {
// //         return id;
// //     }

// //     public void setId(Long id) {
// //         this.id = id;
// //     }

// //     public String getName() {
// //         return name;
// //     }

// //     public void setName(String name) {
// //         this.name = name;
// //     }

// //     public String getDescription() {
// //         return description;
// //     }

// //     public void setDescription(String description) {
// //         this.description = description;
// //     }

// //     public List<Material> getMaterials() {
// //         return materials;
// //     }

// //     public void setMaterials(List<Material> materials) {
// //         this.materials = materials;
// //     }

// //     public List<Enrollment> getEnrollments() {
// //         return enrollments;
// //     }

// //     public void setEnrollments(List<Enrollment> enrollments) {
// //         this.enrollments = enrollments;
// //     }
// // }


package com.prjgrp.artf.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "courses")
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;  // Ensure this field exists
    private String description;  // Example additional field

    // Constructors, getters, and setters
    public Course() {}

    public Course(Long id, String title, String description) {
        this.id = id;
        this.title = title;
        this.description = description;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
