// // package com.prjgrp.artf.entity;

// // import jakarta.persistence.*;
// // import lombok.*;

// // @Entity
// // @Data
// // @NoArgsConstructor
// // @AllArgsConstructor
// // public class Material {
// //     @Id
// //     @GeneratedValue(strategy = GenerationType.IDENTITY)
// //     private Long id;
    
// //     @ManyToOne
// //     @JoinColumn(name = "course_id")
// //     private Course course;

// //     private String content;
// // }

// package com.prjgrp.artf.entity;

// import jakarta.persistence.*;

// @Entity
// public class Material {

//     @Id
//     @GeneratedValue(strategy = GenerationType.IDENTITY)
//     private Long id;

//     @ManyToOne
//     @JoinColumn(name = "course_id")
//     private Course course;

//     private String name;
//     private String description;

//     // Default constructor
//     public Material() {}

//     // Constructor with parameters
//     public Material(Long id, Course course, String name, String description) {
//         this.id = id;
//         this.course = course;
//         this.name = name;
//         this.description = description;
//     }

//     // Getters and Setters
//     public Long getId() {
//         return id;
//     }

//     public void setId(Long id) {
//         this.id = id;
//     }

//     public Course getCourse() {
//         return course;
//     }

//     public void setCourse(Course course) {
//         this.course = course;
//     }

//     public String getName() {
//         return name;
//     }

//     public void setName(String name) {
//         this.name = name;
//     }

//     public String getDescription() {
//         return description;
//     }

//     public void setDescription(String description) {
//         this.description = description;
//     }
// }


package com.prjgrp.artf.entity;

import jakarta.persistence.*;

@Entity
public class Material {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "course_id")
    private Course course;

    private String title;
    private String content;

    // Default constructor
    public Material() {}

    // Constructor with parameters (you can change to match your test case)
    public Material(Long id, String title, String content, Long courseId) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.course = new Course();  // Assuming Course entity exists and has a default constructor
        this.course.setId(courseId); // Set the course ID
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
