// package com.prjgrp.artf.model;

// public class Enrollment {
    
// }

package com.prjgrp.artf.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Enrollment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    
    @JoinColumn(name = "course_id")
    private Course course;

    private String studentName;
}
