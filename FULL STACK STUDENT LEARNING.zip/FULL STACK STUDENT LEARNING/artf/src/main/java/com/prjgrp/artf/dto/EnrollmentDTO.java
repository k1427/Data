package com.prjgrp.artf.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EnrollmentDTO {
    private Long id;
    private Long courseId;
    private String studentName;
}
