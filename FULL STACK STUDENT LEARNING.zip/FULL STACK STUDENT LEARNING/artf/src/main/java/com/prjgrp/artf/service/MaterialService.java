package com.prjgrp.artf.service;

import com.prjgrp.artf.entity.Material;
import com.prjgrp.artf.repository.MaterialRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MaterialService {

    @Autowired
    private MaterialRepository materialRepository;

    // Create a new material
    public Material createMaterial(Material material) {
        return materialRepository.save(material);
    }

    // Get material by ID
    public Material getMaterialById(Long id) {
        Optional<Material> material = materialRepository.findById(id);
        return material.orElseThrow(() -> new RuntimeException("Material not found"));
    }

    // Get all materials
    public List<Material> getAllMaterials() {
        return materialRepository.findAll();
    }

    // Delete a material by ID
    public void deleteMaterial(Long id) {
        if (!materialRepository.existsById(id)) {
            throw new RuntimeException("Material not found");
        }
        materialRepository.deleteById(id);
    }
}
