package com.prjgrp.artf.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MaterialDTO {
    private Long id;
    private Long courseId;
    private String content;
}
