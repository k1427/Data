package com.prjgrp.artf;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.prjgrp.artf.controller.CourseController;
import com.prjgrp.artf.controller.EnrollmentController;
import com.prjgrp.artf.controller.MaterialController;
import com.prjgrp.artf.entity.Course;
import com.prjgrp.artf.entity.Enrollment;
import com.prjgrp.artf.entity.Material;
import com.prjgrp.artf.service.CourseService;
import com.prjgrp.artf.service.EnrollmentService;
import com.prjgrp.artf.service.MaterialService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.Collections;

@WebMvcTest({CourseController.class, EnrollmentController.class, MaterialController.class})
public class ArtfApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CourseService courseService;

    @MockBean
    private EnrollmentService enrollmentService;

    @MockBean
    private MaterialService materialService;

    // Course Tests
    @Test
    public void testCreateCourse() throws Exception {
        Course course = new Course(1L, "Course Title", "Course Description");
        Mockito.when(courseService.createCourse(any(Course.class))).thenReturn(course);

        mockMvc.perform(post("/courses")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(course)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.title").value("Course Title"))
                .andExpect(jsonPath("$.description").value("Course Description"));
    }

    @Test
    public void testGetCourseById() throws Exception {
        Course course = new Course(1L, "Course Title", "Course Description");
        Mockito.when(courseService.getCourseById(anyLong())).thenReturn(course);

        mockMvc.perform(get("/courses/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.title").value("Course Title"))
                .andExpect(jsonPath("$.description").value("Course Description"));
    }

    @Test
    public void testGetAllCourses() throws Exception {
        Course course = new Course(1L, "Course Title", "Course Description");
        Mockito.when(courseService.getAllCourses()).thenReturn(Collections.singletonList(course));

        mockMvc.perform(get("/courses"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].title").value("Course Title"))
                .andExpect(jsonPath("$[0].description").value("Course Description"));
    }

    @Test
    public void testUpdateCourse() throws Exception {
        Course course = new Course(1L, "Updated Course", "Updated Description");
        Mockito.when(courseService.updateCourse(anyLong(), any(Course.class))).thenReturn(course);

        mockMvc.perform(put("/courses/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(course)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.title").value("Updated Course"))
                .andExpect(jsonPath("$.description").value("Updated Description"));
    }

    @Test
    public void testDeleteCourse() throws Exception {
        Mockito.doNothing().when(courseService).deleteCourse(anyLong());

        mockMvc.perform(delete("/courses/1"))
                .andExpect(status().isNoContent());
    }

    
    @Test
    public void testDeleteEnrollment() throws Exception {
        Mockito.doNothing().when(enrollmentService).deleteEnrollment(anyLong());

        mockMvc.perform(delete("/enrollments/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    public void testCreateMaterial() throws Exception {
        Material material = new Material(1L, "Material Title", "Material Content", 1L); // courseId = 1
        Mockito.when(materialService.createMaterial(any(Material.class))).thenReturn(material);

        mockMvc.perform(post("/materials")
                .contentType("application/json")
                .content(new ObjectMapper().writeValueAsString(material)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.title").value("Material Title"))
                .andExpect(jsonPath("$.content").value("Material Content"))
                .andExpect(jsonPath("$.course.id").value(1));
    }

    // Test: Get Material by ID
    @Test
    public void testGetMaterialById() throws Exception {
        Material material = new Material(1L, "Material Title", "Material Content", 1L);
        Mockito.when(materialService.getMaterialById(anyLong())).thenReturn(material);

        mockMvc.perform(get("/materials/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.title").value("Material Title"))
                .andExpect(jsonPath("$.content").value("Material Content"))
                .andExpect(jsonPath("$.course.id").value(1));
    }

    // Test: Get All Materials
    @Test
    public void testGetAllMaterials() throws Exception {
        Material material = new Material(1L, "Material Title", "Material Content", 1L);
        Mockito.when(materialService.getAllMaterials()).thenReturn(Collections.singletonList(material));

        mockMvc.perform(get("/materials"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].title").value("Material Title"))
                .andExpect(jsonPath("$[0].content").value("Material Content"))
                .andExpect(jsonPath("$[0].course.id").value(1));
    }

    @Test
    public void testDeleteMaterial() throws Exception {
        Mockito.doNothing().when(materialService).deleteMaterial(anyLong());

        mockMvc.perform(delete("/materials/1"))
                .andExpect(status().isNoContent());
    }
}
