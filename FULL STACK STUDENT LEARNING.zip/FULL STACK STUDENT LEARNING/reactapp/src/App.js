// src/App.js
import React from 'react';
import './App.css';
import Course from './components/Course/Course';
import Enrollment from './components/Enrollment/Enrollment';
import Material from './components/Material/Material';

function App() {
  return (
    <div className="App">
      <h1>Course Management App</h1>
      <Course />
      <Enrollment />
      <Material />
    </div>
  );
}

export default App;
