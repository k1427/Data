// src/components/Enrollment/Enrollment.js
import React, { useState } from 'react';
import './Enrollment.css';

const Enrollment = () => {
  const [enrollments, setEnrollments] = useState([
    { id: 1, courseId: 1, studentName: 'John Doe' }
  ]);

  const handleDeleteEnrollment = () => {
    setEnrollments([]);
  };

  return (
    <div className="enrollment">
      <h2>Enrollments</h2>
      <ul>
        {enrollments.map((enrollment) => (
          <li key={enrollment.id}>
            <h3>Student: {enrollment.studentName}</h3>
            <button onClick={handleDeleteEnrollment}>Delete Enrollment</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Enrollment;
