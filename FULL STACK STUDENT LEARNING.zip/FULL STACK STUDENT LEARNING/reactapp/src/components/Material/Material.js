// src/components/Material/Material.js
import React, { useState } from 'react';
import './Material.css';

const Material = () => {
  const [materials, setMaterials] = useState([
    { id: 1, title: 'Material Title', content: 'Material Content', courseId: 1 }
  ]);
  const [showForm, setShowForm] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);

  const handleAddMaterial = () => setShowForm(true);

  const handleFormSubmit = (e) => {
    e.preventDefault();
    setShowSuccessMessage(true);
    setShowForm(false);
    setMaterials([...materials, { id: materials.length + 1, title: 'New Material', content: 'New material content' }]);
  };

  return (
    <div className="material">
      <h2>Materials</h2>
      <ul>
        {materials.map((material) => (
          <li key={material.id}>
            <h3>{material.title}</h3>
            <p>{material.content}</p>
            <button>Delete Material</button>
          </li>
        ))}
      </ul>
      <button onClick={handleAddMaterial}>Add Material</button>

      {showForm && (
        <form onSubmit={handleFormSubmit}>
          <label htmlFor="title">Title:</label>
          <input id="title" type="text" />
          <label htmlFor="content">Content:</label>
          <input id="content" type="text" />
          <button type="submit">Submit Material</button>
        </form>
      )}

      {showSuccessMessage && <p>Material added successfully!</p>}
    </div>
  );
};

export default Material;
