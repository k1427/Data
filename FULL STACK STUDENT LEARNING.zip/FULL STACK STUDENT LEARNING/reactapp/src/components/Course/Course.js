// src/components/Course/Course.js
import React, { useState } from 'react';
import './Course.css';

const Course = () => {
  const [courses, setCourses] = useState([
    { id: 1, title: 'Course Title', description: 'Course Description' }
  ]);
  const [showForm, setShowForm] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [showDescription, setShowDescription] = useState(false);

  const handleAddCourse = () => setShowForm(true);
  const handleViewDetails = () => setShowDescription(true);

  const handleFormSubmit = (e) => {
    e.preventDefault();
    setShowSuccessMessage(true);
    setShowForm(false);
    setCourses([...courses, { id: courses.length + 1, title: 'New Course', description: 'New course description' }]);
  };

  return (
    <div className="course">
      <h2>Courses</h2>
      <ul>
        {courses.map((course) => (
          <li key={course.id}>
            <h3>{course.title}</h3>
            <button onClick={handleViewDetails}>View Details</button>
            {showDescription && <p>{course.description}</p>}
          </li>
        ))}
      </ul>
      <button onClick={handleAddCourse}>Add Course</button>

      {showForm && (
        <form onSubmit={handleFormSubmit}>
          <label htmlFor="title">Title:</label>
          <input id="title" type="text" />
          <label htmlFor="description">Description:</label>
          <input id="description" type="text" />
          <button type="submit">Submit Course</button>
        </form>
      )}

      {showSuccessMessage && <p>Course added successfully!</p>}
    </div>
  );
};

export default Course;
