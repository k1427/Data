// src/tests/App.test.js
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import App from '../App';
import Course from '../components/Course/Course';
import Enrollment from '../components/Enrollment/Enrollment';
import Material from '../components/Material/Material';

describe('Course Management App', () => {
  
  // 1. Test to check if 'Course Management App' title is present
  test('renders static content correctly', async () => {
    render(<App />);

    // Check if "Course Management App" title is displayed
    const appTitle = screen.getByText(/Course Management App/i);
    expect(appTitle).toBeInTheDocument();
  });

  // 2. Test to check if 'Courses' section title is present in Course component
  test('renders Courses section title', async () => {
    render(<Course />);

    // Check if "Courses" title is displayed
    const coursesTitle = screen.getByText(/Courses/i);
    expect(coursesTitle).toBeInTheDocument();
  });

  // 3. Test to click 'View Details' button in Course component and show description text
  test('click View Details button and show course description', async () => {
    render(<Course />);

    // Assuming "View Details" button would show description text
    const viewDetailsButton = await screen.findAllByText(/View Details/i);
    fireEvent.click(viewDetailsButton[0]); // Click the first button

    // Check if description text appears
    const descriptionText = await screen.findByText(/Course Description/i);
    expect(descriptionText).toBeInTheDocument();
  });

  // 4. Test case for clicking Add Course button and checking form fields
  test('click Add Course button and check fields', async () => {
    render(<Course />);

    // Click the Add Course button to open the form
    const addCourseButton = await screen.findByText(/Add Course/i);
    fireEvent.click(addCourseButton);

    // Check for form fields after button click
    await waitFor(() => {
      const titleField = screen.getByLabelText(/Title:/i);
      const descriptionField = screen.getByLabelText(/Description:/i);
      const submitButton = screen.getByRole('button', { name: /Submit Course/i });

      expect(titleField).toBeInTheDocument();
      expect(descriptionField).toBeInTheDocument();
      expect(submitButton).toBeInTheDocument();
    });
  });

  // 5. Test case to simulate adding a course
  test('submit course form and show success message', async () => {
    render(<Course />);

    // Open the form by clicking Add Course button
    fireEvent.click(screen.getByText(/Add Course/i));

    // Fill in the form fields
    fireEvent.change(screen.getByLabelText(/Title:/i), { target: { value: 'Advanced Math' } });
    fireEvent.change(screen.getByLabelText(/Description:/i), { target: { value: 'Math course for advanced learners' } });

    // Submit the form
    fireEvent.click(screen.getByRole('button', { name: /Submit Course/i }));

    // Check for success message
    await waitFor(() => {
      expect(screen.getByText(/Course added successfully!/i)).toBeInTheDocument();
    });
  });

  // 6. Test to check the Enrollment component title is present
  test('renders Enrollments section title', async () => {
    render(<Enrollment />);

    // Check if "Enrollments" title is displayed
    const enrollmentTitle = screen.getByText(/Enrollments/i);
    expect(enrollmentTitle).toBeInTheDocument();
  });

  // 7. Test case to delete an enrollment
  test('delete an Enrollment and check if enrollment is removed', async () => {
    render(<Enrollment />);

    // Assuming "Delete Enrollment" button removes enrollment from list
    fireEvent.click(screen.getByText(/Delete Enrollment/i));

    // Check if the enrollment is removed
    await waitFor(() => {
      expect(screen.queryByText(/Student: John Doe/i)).not.toBeInTheDocument();
    });
  });

  // 8. Test to check the Material component title is present
  test('renders Materials section title', async () => {
    render(<Material />);

    // Check if "Materials" title is displayed
    const materialsTitle = screen.getByText(/Materials/i);
    expect(materialsTitle).toBeInTheDocument();
  });

  // 9. Test case for clicking Add Material button and checking form fields
  test('click Add Material button and check fields', async () => {
    render(<Material />);

    // Click the Add Material button to open the form
    const addMaterialButton = await screen.findByText(/Add Material/i);
    fireEvent.click(addMaterialButton);

    // Check for form fields after button click
    await waitFor(() => {
      const titleField = screen.getByLabelText(/Title:/i);
      const contentField = screen.getByLabelText(/Content:/i);
      const submitButton = screen.getByRole('button', { name: /Submit Material/i });

      expect(titleField).toBeInTheDocument();
      expect(contentField).toBeInTheDocument();
      expect(submitButton).toBeInTheDocument();
    });
  });

  // 10. Test case to simulate adding a material
  test('submit material form and show success message', async () => {
    render(<Material />);

    // Open the form by clicking Add Material button
    fireEvent.click(screen.getByText(/Add Material/i));

    // Fill in the form fields
    fireEvent.change(screen.getByLabelText(/Title:/i), { target: { value: 'Chemistry Basics' } });
    fireEvent.change(screen.getByLabelText(/Content:/i), { target: { value: 'Introduction to basic concepts in chemistry' } });

    // Submit the form
    fireEvent.click(screen.getByRole('button', { name: /Submit Material/i }));

    // Check for success message
    await waitFor(() => {
      expect(screen.getByText(/Material added successfully!/i)).toBeInTheDocument();
    });
  });
});
