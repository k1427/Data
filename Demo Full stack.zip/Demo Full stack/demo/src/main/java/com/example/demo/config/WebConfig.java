// package com.example.demo.config;

// import org.springframework.context.annotation.Configuration;
// import org.springframework.web.servlet.config.annotation.CorsRegistry;
// import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

// @Configuration
// public class WebConfig implements WebMvcConfigurer {

//     @Override
//     public void addCorsMappings(CorsRegistry registry) {
//         // Allow CORS for all endpoints under '/api/**'
//         registry.addMapping("/api/**")  // Match all API endpoints
//                 .allowedOrigins("http://8081-ffacdabdabdaf322537523abbeebabcabtwo.premiumproject.examly.io/")  // Your frontend URL
//                 .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")  // Ensure OPTIONS is allowed
//                 .allowedHeaders("Content-Type", "Authorization", "X-Requested-With", "*")  // Allow necessary headers
//                 .allowCredentials(true)  // Allow credentials (cookies, authorization headers)
//                 .maxAge(3600);  // Cache pre-flight response for 1 hour
//     }
// }
