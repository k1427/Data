import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import UserForm from './components/UserForm';
import UserList from './components/UserList';

const App = () => {
  return (
    <Router>
      <div>
        <h1>User Management</h1>
        <Routes>
          {/* Default route should point to UserForm */}
          <Route path="/user-form/:userId" element={<UserForm />} />
          <Route path="/user-form" element={<UserForm />} />
          <Route path="/" element={<UserList />} />  {/* Navigate to UserList as default */}
        </Routes>
      </div>
    </Router>
  );
};

export default App;
