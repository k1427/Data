import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';  
import axios from 'axios';

const API_URL = 'https://8080-ffacdabdabdaf322537523abbeebabcabtwo.premiumproject.examly.io/api/users';  // Adjust to your backend URL

const UserForm = () => {
  const [user, setUser] = useState({
    username: '',
    password: '',
    email: '',
    firstName: '',
    lastName: '',
    phoneNumber: '',
    address: '',
  });
  
  const { userId } = useParams();
  const navigate = useNavigate(); 

  // Get user data for editing (if userId is present)
  useEffect(() => {
    if (userId) {
      axios.get(`${API_URL}/${userId}`)
        .then((response) => {
          setUser(response.data);
        })
        .catch((error) => {
          console.error("Error fetching user:", error);
        });
    }
  }, [userId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser((prevUser) => ({
      ...prevUser,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const apiRequest = userId
      ? axios.put(`${API_URL}/${userId}`, user)  // Update user
      : axios.post(API_URL, user);  // Create new user

    apiRequest
      .then(() => {
        alert(userId ? 'User updated successfully' : 'User created successfully');
        navigate('/'); // Navigate to the home page after the action
      })
      .catch((error) => {
        console.error(userId ? 'Error updating user' : 'Error creating user', error);
      });
  };

  return (
    <div>
      <h2>{userId ? 'Update' : 'Create'} User</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Username:</label>
          <input
            type="text"
            name="username"
            value={user.username}
            onChange={handleChange}
            required
          />
        </div>

        <div>
          <label>Password:</label>
          <input
            type="password"
            name="password"
            value={user.password}
            onChange={handleChange}
            required
          />
        </div>

        <div>
          <label>Email:</label>
          <input
            type="email"
            name="email"
            value={user.email}
            onChange={handleChange}
            required
          />
        </div>

        <div>
          <label>First Name:</label>
          <input
            type="text"
            name="firstName"
            value={user.firstName}
            onChange={handleChange}
          />
        </div>

        <div>
          <label>Last Name:</label>
          <input
            type="text"
            name="lastName"
            value={user.lastName}
            onChange={handleChange}
          />
        </div>

        <div>
          <label>Phone Number:</label>
          <input
            type="text"
            name="phoneNumber"
            value={user.phoneNumber}
            onChange={handleChange}
          />
        </div>

        <div>
          <label>Address:</label>
          <input
            type="text"
            name="address"
            value={user.address}
            onChange={handleChange}
          />
        </div>

        <button type="submit">{userId ? 'Update' : 'Create'} User</button>
      </form>
    </div>
  );
};

export default UserForm;
