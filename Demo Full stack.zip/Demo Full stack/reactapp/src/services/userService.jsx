import axios from 'axios';

const API_URL = 'https://8080-ffacdabdabdaf322537523abbeebabcabtwo.premiumproject.examly.io/';  // Adjust to your backend URL

// Get all users
export const getUsers = async () => {
  try {
    const response = await axios.get(API_URL);
    return response.data;  // Return the data from the response
  } catch (error) {
    console.error('Error fetching users:', error);
    throw error;  // Rethrow error for further handling if needed
  }
};

// Get a user by ID
export const getUserById = async (userId) => {
  try {
    const response = await axios.get(`${API_URL}/${userId}`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching user with ID ${userId}:`, error);
    throw error;
  }
};

// Create a new user
export const createUser = async (user) => {
  try {
    const response = await axios.post(API_URL, user);
    return response.data;
  } catch (error) {
    console.error('Error creating user:', error);
    throw error;
  }
};

// Update an existing user
export const updateUser = async (userId, user) => {
  try {
    const response = await axios.put(`${API_URL}/${userId}`, user);
    return response.data;
  } catch (error) {
    console.error(`Error updating user with ID ${userId}:`, error);
    throw error;
  }
};

// Delete a user
export const deleteUser = async (userId) => {
  try {
    await axios.delete(`${API_URL}/${userId}`);
  } catch (error) {
    console.error(`Error deleting user with ID ${userId}:`, error);
    throw error;
  }
};
