package com.rechargebackend.pulsetopupbackend;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rechargebackend.pulsetopupbackend.Controller.HistoryController;
import com.rechargebackend.pulsetopupbackend.Model.History;
import com.rechargebackend.pulsetopupbackend.Model.RechargePlan;
import com.rechargebackend.pulsetopupbackend.Model.User;
import com.rechargebackend.pulsetopupbackend.Service.HistoryService;
import com.rechargebackend.pulsetopupbackend.Service.RechargePlanService;
import com.rechargebackend.pulsetopupbackend.Service.UserService;
import com.rechargebackend.pulsetopupbackend.configuration.SwaggerConfig;



@AutoConfigureMockMvc
@TestMethodOrder(OrderAnnotation.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class CombinedControllerTest {
    private static final String LOG_FOLDER_PATH = "logs";
    private static final String LOG_FILE_PATH = "logs/application.log"; 
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private TestRestTemplate restTemplate;
    
    @MockBean
    private UserService userService;

    @MockBean
    private HistoryService historyService;
    
    @MockBean
    private RechargePlanService rechargePlanService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void testCreateRechargePlan() throws Exception {
        RechargePlan rechargePlan = new RechargePlan();
        rechargePlan.setId(1L);
        rechargePlan.setPlanName("Basic Plan");
        rechargePlan.setPlanDescription("A basic plan with limited features");
        rechargePlan.setPlanDuration(30);
        rechargePlan.setPrice(99.99);

        when(rechargePlanService.create(Mockito.any(RechargePlan.class))).thenReturn(rechargePlan);

        mockMvc.perform(post("/RechargePlan")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(rechargePlan)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.planName").value("Basic Plan"))
                .andExpect(jsonPath("$.price").value(99.99));

        verify(rechargePlanService, times(1)).create(Mockito.any(RechargePlan.class));
    }

    @Test
    public void testFindAllRechargePlans() throws Exception {
        RechargePlan plan1 = new RechargePlan();
        plan1.setId(1L);
        plan1.setPlanName("Basic Plan");
        plan1.setPlanDescription("A basic plan with limited features");
        plan1.setPlanDuration(30);
        plan1.setPrice(99.99);

        RechargePlan plan2 = new RechargePlan();
        plan2.setId(2L);
        plan2.setPlanName("Premium Plan");
        plan2.setPlanDescription("A premium plan with advanced features");
        plan2.setPlanDuration(90);
        plan2.setPrice(299.99);

        List<RechargePlan> planList = Arrays.asList(plan1, plan2);

        when(rechargePlanService.findAll()).thenReturn(planList);

        mockMvc.perform(get("/RechargePlan")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[1].id").value(2));

        verify(rechargePlanService, times(1)).findAll();
    }

    @Test
    public void testFindRechargePlanById() throws Exception {
        RechargePlan rechargePlan = new RechargePlan();
        rechargePlan.setId(1L);
        rechargePlan.setPlanName("Basic Plan");
        rechargePlan.setPlanDescription("A basic plan with limited features");
        rechargePlan.setPlanDuration(30);
        rechargePlan.setPrice(99.99);

        when(rechargePlanService.findById(1L)).thenReturn(rechargePlan);

        mockMvc.perform(get("/RechargePlan/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.planName").value("Basic Plan"));

        verify(rechargePlanService, times(1)).findById(1L);
    }

    @Test
    public void testUpdateRechargePlan() throws Exception {
        RechargePlan updatedPlan = new RechargePlan();
        updatedPlan.setId(1L);
        updatedPlan.setPlanName("Updated Plan");
        updatedPlan.setPlanDescription("Updated description");
        updatedPlan.setPlanDuration(60);
        updatedPlan.setPrice(199.99);

        when(rechargePlanService.update(eq(1L), Mockito.any(RechargePlan.class))).thenReturn(updatedPlan);

        mockMvc.perform(put("/RechargePlan/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updatedPlan)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.planName").value("Updated Plan"))
                .andExpect(jsonPath("$.price").value(199.99));

        verify(rechargePlanService, times(1)).update(eq(1L), Mockito.any(RechargePlan.class));
    }

    @Test
    public void testDeleteRechargePlan() throws Exception {
        doNothing().when(rechargePlanService).delete(1L);

        mockMvc.perform(delete("/RechargePlan/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        verify(rechargePlanService, times(1)).delete(1L);
    }

     @Test
    public void testCreateHistory() throws Exception {
        History history = new History();
        history.setId(1L);
        history.setUserId(1);
        history.setRechargePlan("Plan A");
        history.setDate(LocalDate.now());
        history.setTime("10:00 AM");

        when(historyService.create(Mockito.any(History.class))).thenReturn(history);

        mockMvc.perform(post("/History")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(history)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.userId").value(1))
                .andExpect(jsonPath("$.rechargePlan").value("Plan A"));

        verify(historyService, times(1)).create(Mockito.any(History.class));
    }

    @Test
    public void testFindAllHistories() throws Exception {
        History history1 = new History();
        history1.setId(1L);
        history1.setUserId(1);
        history1.setRechargePlan("Plan A");
        history1.setDate(LocalDate.now());
        history1.setTime("10:00 AM");

        History history2 = new History();
        history2.setId(2L);
        history2.setUserId(2);
        history2.setRechargePlan("Plan B");
        history2.setDate(LocalDate.now());
        history2.setTime("11:00 AM");

        List<History> historyList = Arrays.asList(history1, history2);

        when(historyService.findAll()).thenReturn(historyList);

        mockMvc.perform(get("/History")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[1].id").value(2));

        verify(historyService, times(1)).findAll();
    }

    @Test
    public void testFindHistoryById() throws Exception {
        History history = new History();
        history.setId(1L);
        history.setUserId(1);
        history.setRechargePlan("Plan A");
        history.setDate(LocalDate.now());
        history.setTime("10:00 AM");

        when(historyService.findById(1L)).thenReturn(history);

        mockMvc.perform(get("/History/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.rechargePlan").value("Plan A"));

        verify(historyService, times(1)).findById(1L);
    }

    @Test
    public void testUpdateHistory() throws Exception {
        History updatedHistory = new History();
        updatedHistory.setId(1L);
        updatedHistory.setUserId(1);
        updatedHistory.setRechargePlan("Updated Plan");
        updatedHistory.setDate(LocalDate.now());
        updatedHistory.setTime("12:00 PM");

        when(historyService.update(eq(1L), Mockito.any(History.class))).thenReturn(updatedHistory);

        mockMvc.perform(put("/History/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updatedHistory)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.rechargePlan").value("Updated Plan"));

        verify(historyService, times(1)).update(eq(1L), Mockito.any(History.class));
    }

    @Test
    public void testDeleteHistory() throws Exception {
        doNothing().when(historyService).delete(1L);

        mockMvc.perform(delete("/History/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        verify(historyService, times(1)).delete(1L);
    }

    @Test
    void testCreateUser() throws Exception {
        User user = new User();
        user.setId(1L);
        user.setUsername("John Doe");
        user.setEmail("john.doe@example.com");

        when(userService.createUser(any(User.class))).thenReturn(user);

        mockMvc.perform(post("/api/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\": \"John Doe\", \"email\": \"john.doe@example.com\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("John Doe"))
                .andExpect(jsonPath("$.email").value("john.doe@example.com"));
    }

    @Test
    void testGetUserById() throws Exception {
        User user = new User();
        user.setId(1L);
        user.setUsername("John Doe");
        user.setEmail("john.doe@example.com");

        when(userService.getUserById(anyLong())).thenReturn(Optional.of(user));

        mockMvc.perform(get("/api/users/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("John Doe"))
                .andExpect(jsonPath("$.email").value("john.doe@example.com"));
    }

    @Test
    void testGetUserByIdNotFound() throws Exception {
        when(userService.getUserById(anyLong())).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/users/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    void testGetAllUsers() throws Exception {
        User user1 = new User();
        user1.setId(1L);
        user1.setUsername("John Doe");
        user1.setEmail("john.doe@example.com");

        User user2 = new User();
        user2.setId(2L);
        user2.setUsername("Jane Doe");
        user2.setEmail("jane.doe@example.com");

        when(userService.getAllUsers()).thenReturn(Arrays.asList(user1, user2));

        mockMvc.perform(get("/api/users")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].username").value("John Doe"))
                .andExpect(jsonPath("$[0].email").value("john.doe@example.com"))
                .andExpect(jsonPath("$[1].id").value(2))
                .andExpect(jsonPath("$[1].username").value("Jane Doe"))
                .andExpect(jsonPath("$[1].email").value("jane.doe@example.com"));
    }

    @Test
    void testUpdateUser() throws Exception {
        User user = new User();
        user.setId(1L);
        user.setUsername("John Doe");
        user.setEmail("john.doe@example.com");

        User updatedUser = new User();
        updatedUser.setId(1L);
        updatedUser.setUsername("John Smith");
        updatedUser.setEmail("john.smith@example.com");

        when(userService.updateUser(anyLong(), any(User.class))).thenReturn(Optional.of(updatedUser));

        mockMvc.perform(put("/api/users/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\": \"John Smith\", \"email\": \"john.smith@example.com\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("John Smith"))
                .andExpect(jsonPath("$.email").value("john.smith@example.com"));
    }

    @Test
    void testUpdateUserNotFound() throws Exception {
        when(userService.updateUser(anyLong(), any(User.class))).thenReturn(Optional.empty());

        mockMvc.perform(put("/api/users/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\": \"John Smith\", \"email\": \"john.smith@example.com\"}"))
                .andExpect(status().isNotFound());
    }

    @Test
    void testDeleteUser() throws Exception {
        when(userService.deleteUser(anyLong())).thenReturn(true);

        mockMvc.perform(delete("/api/users/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }

    @Test
    void testDeleteUserNotFound() throws Exception {
        when(userService.deleteUser(anyLong())).thenReturn(false);

        mockMvc.perform(delete("/api/users/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

     @Test
     @Order(37)
    public void test_OneToMany_Annotation() throws IOException {
        // Path to the file to be tested
        String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Model/User.java";
        String searchString = "@OneToMany";
 
        boolean containsString = false;
 
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(searchString)) {
                    containsString = true;
                    break;
                }
            }
        }
 
        // Assert that the string is present in the file
        assertTrue(containsString, "The file does not contain the string '@OneToMany'");
    }
     @Test
     @Order(38)
    public void test_OneToOne_Annotation() throws IOException {
        // Path to the file to be tested
        String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Model/ContactSupport.java";
        String searchString = "@OneToOne";
 
        boolean containsString = false;
 
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(searchString)) {
                    containsString = true;
                    break;
                }
            }
        }
 
        // Assert that the string is present in the file
        assertTrue(containsString, "The file does not contain the string '@OneToOne'");
    }
     @Test
     @Order(39)
    public void test_ManyToMany_Annotation() throws IOException {
        // Path to the file to be tested
        String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Model/RechargePlan.java";
        String searchString = "@ManyToMany";
 
        boolean containsString = false;
 
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(searchString)) {
                    containsString = true;
                    break;
                }
            }
        }
 
        // Assert that the string is present in the file
        assertTrue(containsString, "The file does not contain the string 'ManyToMany'");
    }
    @Test
    public void testCustomOpenAPIBeanCreation() {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SwaggerConfig.class);
        OpenAPI openAPI = context.getBean(OpenAPI.class);

        assertNotNull(openAPI, "OpenAPI bean should not be null.");
        Info info = openAPI.getInfo();
        assertNotNull(info, "OpenAPI Info should not be null.");
        assertEquals("My API", info.getTitle());
        assertEquals("1.0", info.getVersion());
        assertEquals("API documentation using Swagger", info.getDescription());
        context.close();
    }

    @Test
    public void testCustomOpenAPIMethodIsAnnotatedWithBean() throws NoSuchMethodException {
        Method method = SwaggerConfig.class.getDeclaredMethod("customOpenAPI");
        Bean beanAnnotation = method.getAnnotation(Bean.class);
        assertTrue(beanAnnotation != null, "customOpenAPI method should be annotated with @Bean.");
    }

    @Test
    public void testConfigurationAnnotation() {
        Configuration configurationAnnotation = SwaggerConfig.class.getAnnotation(Configuration.class);
        assertTrue(configurationAnnotation != null, "SwaggerConfig should be annotated with @Configuration.");
    }
    @Test 
    public void Log_testConfigurationFolder() { 
        String directoryPath = "src/main/java/com/rechargebackend/pulsetopupbackend/configuration"; // Replace with the path to your directory 
        File directory = new File(directoryPath); 
        assertTrue(directory.exists() && directory.isDirectory()); 
    }
    
    @Test
	public void Log_testConfigFile() {

		String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/configuration/SwaggerConfig.java";

		// Replace with the path to your file

		File file = new File(filePath);

		assertTrue(file.exists() && file.isFile());

	}
    
	 
	@Test
    void Log_testSwaggerUIEndpointIsAccessible() {
        // Make a GET request to the Swagger UI URL
        ResponseEntity<String> response = restTemplate.getForEntity("/swagger-ui/index.html", String.class);

        // Assert that the endpoint returns a 200 OK status
        assertEquals(HttpStatus.OK, response.getStatusCode(), "Swagger UI endpoint is not accessible");
    }

    @Test
    public void CRUD_testLogFolderAndFileCreation() {
        // Check if the "logs" folder exists
        File logFolder = new File(LOG_FOLDER_PATH);
        assertTrue(logFolder.exists(), "Log folder should be created");

        // Check if the "application.log" file exists inside the "logs" folder
        File logFile = new File(LOG_FILE_PATH);
        assertTrue(logFile.exists(), "Log file should be created inside 'logs' folder");
    }

    @Test
    void PageAndJPQL_testPagination_User() {
    // Simulate a GET request to fetch users with pagination
    ResponseEntity<String> response = restTemplate.getForEntity("/api/users?page=0&size=10", String.class);
    
    // Assert that the response status is OK
    assertEquals(HttpStatus.OK, response.getStatusCode(), "Response status should be OK");

    // Assert that the response body is not empty (assuming it's a JSON array of users)
    assertNotNull(response.getBody(), "Response body should not be null");
    }
    @Test
    void PageAndJPQL_testPagination_RechargePlan() {
    // Simulate a GET request to fetch users with pagination
    ResponseEntity<String> response = restTemplate.getForEntity("/RechargePlan?page=0&size=10", String.class);
    
    // Assert that the response status is OK
    assertEquals(HttpStatus.OK, response.getStatusCode(), "Response status should be OK");

    // Assert that the response body is not empty (assuming it's a JSON array of users)
    assertNotNull(response.getBody(), "Response body should not be null");
    }

    @Test
    void Log_testAopFunctionality() {
        // Trigger AOP by making a GET request to UserController
        ResponseEntity<String> response = restTemplate.getForEntity("/api/users", String.class);

        // Assert that the response is valid (indicating the controller method was executed)
        assertNotNull(response.getBody());

        // You can check the console log for the "AOP: Method called" message
    }



}
