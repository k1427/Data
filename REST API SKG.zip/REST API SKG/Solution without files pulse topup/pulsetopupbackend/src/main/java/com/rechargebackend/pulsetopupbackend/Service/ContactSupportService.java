package com.rechargebackend.pulsetopupbackend.Service;
import com.rechargebackend.pulsetopupbackend.Model.*;
import com.rechargebackend.pulsetopupbackend.Repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ContactSupportService {
    @Autowired
    private ContactSupportRepository repository;

    public ContactSupport create(ContactSupport support) {
        return repository.save(support);
    }

    public List<ContactSupport> findAll() {
        return repository.findAll();
    }
}

