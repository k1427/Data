package com.rechargebackend.pulsetopupbackend.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.rechargebackend.pulsetopupbackend.Model.History;

public interface HistoryRepository extends JpaRepository<History, Long> {}
