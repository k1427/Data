package com.rechargebackend.pulsetopupbackend.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;

@Aspect
@Component
public class LoggingAspect {

    private static final Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

    // Define a pointcut for methods in AuthorService
    @Pointcut("execution(* com.example.demo.service.AuthorService.getAllAuthors(..))")
    public void getAllAuthorsMethod() {}

    // Before advice: Executes before getAllAuthors method execution
    @Before("getAllAuthorsMethod()")
    public void logBefore() {
        logger.info("Fetching all authors...");
    }

    // After returning advice: Executes after getAllAuthors method execution successfully
    @AfterReturning(pointcut = "getAllAuthorsMethod()", returning = "result")
    public void logAfterReturning(Object result) {
        logger.info("Successfully fetched all authors, count: {}", ((List<?>) result).size());
    }
}
