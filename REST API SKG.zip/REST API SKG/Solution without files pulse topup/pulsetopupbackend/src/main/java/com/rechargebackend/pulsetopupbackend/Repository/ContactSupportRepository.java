package com.rechargebackend.pulsetopupbackend.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.rechargebackend.pulsetopupbackend.Model.ContactSupport;
public interface ContactSupportRepository extends JpaRepository<ContactSupport, Long> {}
