package com.rechargebackend.pulsetopupbackend.Service;

import com.rechargebackend.pulsetopupbackend.Model.History;
import com.rechargebackend.pulsetopupbackend.Repository.HistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HistoryService {

    private final HistoryRepository historyRepository;

    @Autowired
    public HistoryService(HistoryRepository historyRepository) {
        this.historyRepository = historyRepository;
    }

    public History create(History history) {
        return historyRepository.save(history);
    }

    public List<History> findAll() {
        return historyRepository.findAll();
    }

    public History findById(Long id) {
        return historyRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("History record not found for ID: " + id));
    }

    public History update(Long id, History updatedHistory) {
        History existingHistory = findById(id);
        existingHistory.setUserId(updatedHistory.getUserId());
        existingHistory.setRechargePlan(updatedHistory.getRechargePlan());
        existingHistory.setDate(updatedHistory.getDate());
        existingHistory.setTime(updatedHistory.getTime());
        return historyRepository.save(existingHistory);
    }

    public void delete(Long id) {
        History history = findById(id);
        historyRepository.delete(history);
    }
}
