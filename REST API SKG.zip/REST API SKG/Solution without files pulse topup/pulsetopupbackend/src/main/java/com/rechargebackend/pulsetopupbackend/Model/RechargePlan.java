package com.rechargebackend.pulsetopupbackend.Model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.Data;
@Data
@Entity
public class RechargePlan {
    //@ManyToMany
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String planName;
    private String planDescription;
    private Integer planDuration;
    private Double price;
}
