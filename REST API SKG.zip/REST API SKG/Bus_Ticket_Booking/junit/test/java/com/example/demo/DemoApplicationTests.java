package com.example.demo;

import com.example.demo.entity.Admin;
import com.example.demo.entity.Bus;
import com.example.demo.service.AdminService;
import com.example.demo.service.BusService;
import com.example.demo.entity.Driver;
import com.example.demo.service.DriverService;
import com.example.demo.service.UserService;
import com.example.demo.entity.User;
import com.example.demo.repository.BusRepository;
import com.example.demo.repository.DriverRepository;
import com.example.demo.repository.UserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
@AutoConfigureMockMvc
class DemoApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private AdminService adminService;

	@MockBean
	private BusService busService;

	@MockBean
	private DriverService driverService;

	@MockBean
	private UserService userService;

	@Autowired
	private DriverRepository driverRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private BusRepository busRepository;


    private ObjectMapper objectMapper = new ObjectMapper();  // Jackson ObjectMapper for JSON conversion


	@Test
    @Order(1)
	void contextLoads() {
	}
	@Test
    @Order(2)
	void Annotation_testAdminHasLombokAnnotations() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Admin.java");

		String entityFileContent = Files.readString(entityFilePath);

		assertTrue(entityFileContent.contains("@Data"), "Admin entity should contain @Data annotation");
		assertTrue(entityFileContent.contains("@NoArgsConstructor"),
				"Author entity should contain @NoArgsConstructor annotation");
	}

	@Test
    @Order(3)
	void Annotation_testBusHasLombokAnnotations() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Bus.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@Data"), "Bus entity should contain @Data annotation");
	}

	@Test
    @Order(4)
	void Annotation_testAdminHasJSONIgnoreAnnotations() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Admin.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@JsonIgnore"), "Admin entity should contain @JsonIgnore annotation");
	}

	@Test
    @Order(5)
	void Annotation_testUserHasJSONIgnoreAnnotations() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/User.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@JsonIgnore"), "User entity should contain @JsonIgnore annotation");
	}

    @Test
    @Order(6)
	void Repository_testAdminRepository() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/repository/AdminRepository.java");
		assertTrue(Files.exists(entityFilePath), "AdminRepository file should exist");
	}

	@Test
    @Order(7)
	void Repository_testBusRepository() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/repository/BusRepository.java");
		assertTrue(Files.exists(entityFilePath), "Bus Repository file should exist");
	}

	@Test
    @Order(8)
	void Repository_testDriverRepository() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/repository/DriverRepository.java");
		assertTrue(Files.exists(entityFilePath), "Driver Repository file should exist");
	}

	@Test
    @Order(9)
	void Repository_testUserRepository() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/repository/UserRepository.java");
		assertTrue(Files.exists(entityFilePath), "User Repository file should exist");
	}

	@Test
    @Order(10)
    void CRUD_testGetAllAdmins() throws Exception {
        List<Admin> admins = Arrays.asList(
                new Admin(1L, "Admin One", "admin1@example.com", "password1"),
                new Admin(2L, "Admin Two", "admin2@example.com", "password2")
        );

        when(adminService.getAllAdmins()).thenReturn(admins);

        mockMvc.perform(get("/api/admins"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(admins.size()))
                .andExpect(jsonPath("$[0].name").value("Admin One"))
                .andExpect(jsonPath("$[1].name").value("Admin Two"));

        verify(adminService, times(1)).getAllAdmins();
    }

    @Test
    @Order(11)
    void CRUD_testGetAdminById() throws Exception {
        Long adminId = 1L;
        Admin admin = new Admin(adminId, "Admin One", "admin1@example.com", "password1");

        when(adminService.getAdminById(adminId)).thenReturn(admin);

        mockMvc.perform(get("/api/admins/{id}", adminId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Admin One"))
                .andExpect(jsonPath("$.email").value("admin1@example.com"));

        verify(adminService, times(1)).getAdminById(adminId);
    }

    @Test
    @Order(12)
    void CRUD_testCreateAdmin() throws Exception {
        Admin admin = new Admin(null, "Admin One", "admin1@example.com", "password1");
        Admin savedAdmin = new Admin(1L, "Admin One", "admin1@example.com", "password1");

        when(adminService.createAdmin(Mockito.any(Admin.class))).thenReturn(savedAdmin);

        mockMvc.perform(post("/api/admins")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(admin)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(savedAdmin.getId()))
                .andExpect(jsonPath("$.name").value(savedAdmin.getName()));

        verify(adminService, times(1)).createAdmin(Mockito.any(Admin.class));
    }

    @Test
    @Order(13)
    void CRUD_testDeleteAdmin() throws Exception {
        Long adminId = 1L;

        doNothing().when(adminService).deleteAdmin(adminId);

        mockMvc.perform(delete("/api/admins/{id}", adminId))
                .andExpect(status().isOk());

        verify(adminService, times(1)).deleteAdmin(adminId);
    }

    @Test
    @Order(14)
    void CRUD_testGetAllAdminsPaginate() throws Exception {
        int page = 0;
        int size = 10;

        mockMvc.perform(get("/api/admins/paginate")
                .param("page", String.valueOf(page))
                .param("size", String.valueOf(size)))
                .andExpect(status().isOk());

        verify(adminService, times(1)).getAllAdminsPaginate(page, size);
    }

	@Test
    @Order(15)
    void CRUD_testGetAllBuses() throws Exception {
        List<Bus> buses = new ArrayList<>();
        Bus bus1 = new Bus();
        bus1.setBusNumber("123A");
        bus1.setRoute("Route A");
        bus1.setCapacity(40);
        bus1.setDriverName("John Doe");

        Bus bus2 = new Bus();
        bus2.setBusNumber("456B");
        bus2.setRoute("Route B");
        bus2.setCapacity(30);
        bus2.setDriverName("Jane Doe");

        buses.add(bus1);
        buses.add(bus2);

        // Mock service method
        when(busService.getAllBuses()).thenReturn(buses);

        // Perform GET request and verify response
        mockMvc.perform(get("/api/buses"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(buses.size()))
                .andExpect(jsonPath("$[0].busNumber").value("123A"))
                .andExpect(jsonPath("$[1].busNumber").value("456B"));

        // Verify service interaction
        verify(busService, times(1)).getAllBuses();
    }

    @Test
    @Order(16)
    void CRUD_testGetSortedBuses() throws Exception {
        List<Bus> buses = new ArrayList<>();
        Bus bus1 = new Bus();
        bus1.setBusNumber("123A");
        bus1.setRoute("Route A");
        bus1.setCapacity(40);
        bus1.setDriverName("John Doe");

        Bus bus2 = new Bus();
        bus2.setBusNumber("456B");
        bus2.setRoute("Route B");
        bus2.setCapacity(30);
        bus2.setDriverName("Jane Doe");

        buses.add(bus1);
        buses.add(bus2);

        buses.sort(Comparator.comparing(Bus::getRoute));

        when(busService.getSortedBuses("route")).thenReturn(buses);

        mockMvc.perform(get("/api/buses/sorted").param("sortBy", "route"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(buses.size()))
                .andExpect(jsonPath("$[0].route").value("Route A"))
                .andExpect(jsonPath("$[1].route").value("Route B"));

        verify(busService, times(1)).getSortedBuses("route");
    }

    @Test
    @Order(17)
    void CRUD_testCreateBus() throws Exception {
        Bus bus = new Bus();
        bus.setBusNumber("123A");
        bus.setRoute("Route A");
        bus.setCapacity(40);
        bus.setDriverName("John Doe");

        Bus savedBus = new Bus();
        savedBus.setId(1L);
        savedBus.setBusNumber("123A");
        savedBus.setRoute("Route A");
        savedBus.setCapacity(40);
        savedBus.setDriverName("John Doe");

        when(busService.createBus(Mockito.any(Bus.class))).thenReturn(savedBus);

        mockMvc.perform(post("/api/buses")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(bus)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(savedBus.getId()))
                .andExpect(jsonPath("$.busNumber").value("123A"));

        verify(busService, times(1)).createBus(Mockito.any(Bus.class));
    }

    @Test
    @Order(18)
    void CRUD_testDeleteBus() throws Exception {
        Long busId = 1L;

        doNothing().when(busService).deleteBus(busId);

        mockMvc.perform(delete("/api/buses/{id}", busId))
                .andExpect(status().isOk());

        verify(busService, times(1)).deleteBus(busId);
    }
	@Test
    @Order(19)
    void CRUD_testGetAllDrivers() throws Exception {
        // Initialize Bus instance
        Bus bus1 = new Bus();
        bus1.setId(1L);
        bus1.setBusNumber("123A");
        bus1.setRoute("Route A");
        bus1.setCapacity(40);

        // Create Driver instances
        Driver driver1 = new Driver();
        driver1.setId(1L);
        driver1.setName("Driver One");
        driver1.setLicenseNumber("LIC123");
        driver1.setPhone("1234567890");
        driver1.setAssignedBus(bus1);

        Driver driver2 = new Driver();
        driver2.setId(2L);
        driver2.setName("Driver Two");
        driver2.setLicenseNumber("LIC456");
        driver2.setPhone("0987654321");
        driver2.setAssignedBus(bus1);

        List<Driver> drivers = List.of(driver1, driver2);

        // Mock the service
        when(driverService.getAllDrivers()).thenReturn(drivers);

        // Perform GET request and verify response
        mockMvc.perform(get("/api/drivers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(drivers.size()))
                .andExpect(jsonPath("$[0].name").value("Driver One"))
                .andExpect(jsonPath("$[1].name").value("Driver Two"))
                .andExpect(jsonPath("$[0].assignedBus.busNumber").value("123A"));

        verify(driverService, times(1)).getAllDrivers();
    }


    @Test
    @Order(20)
    void CRUD_testCreateDriver() throws Exception {
        // Initialize Bus instance
        Bus bus = new Bus();
        bus.setId(1L);
        bus.setBusNumber("123A");
        bus.setRoute("Route A");
        bus.setCapacity(40);

        // Create Driver instance
        Driver driver = new Driver();
        driver.setName("Driver One");
        driver.setLicenseNumber("LIC123");
        driver.setPhone("1234567890");
        driver.setAssignedBus(bus);

        Driver savedDriver = new Driver();
        savedDriver.setId(1L);
        savedDriver.setName("Driver One");
        savedDriver.setLicenseNumber("LIC123");
        savedDriver.setPhone("1234567890");
        savedDriver.setAssignedBus(bus);

        // Mock the service
        when(driverService.createDriver(Mockito.any(Driver.class))).thenReturn(savedDriver);

        // Perform POST request and verify response
        mockMvc.perform(post("/api/drivers")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(driver)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(savedDriver.getId()))
                .andExpect(jsonPath("$.name").value("Driver One"))
                .andExpect(jsonPath("$.assignedBus.busNumber").value("123A"));

        verify(driverService, times(1)).createDriver(Mockito.any(Driver.class));
    }

    @Test
    @Order(21)
    void CRUD_testDeleteDriver() throws Exception {
        Long driverId = 1L;

        // Mock the service call
        doNothing().when(driverService).deleteDriver(driverId);

        // Perform DELETE request and verify response
        mockMvc.perform(delete("/api/drivers/{id}", driverId))
                .andExpect(status().isOk());

        verify(driverService, times(1)).deleteDriver(driverId);
    }

	//CRUD User
	@Test
    @Order(22)
    public void CRUD_testCreateUser() throws Exception {
        User user = new User(1L, "username", "user@example.com");
        Mockito.when(userService.createUser(any(User.class))).thenReturn(user);

        mockMvc.perform(post("/api/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(user)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("username"))
                .andExpect(jsonPath("$.email").value("user@example.com"));
    }

    @Test
    @Order(23)
    public void CRUD_testGetUserById() throws Exception {
        User user = new User(1L, "username", "user@example.com");
        Mockito.when(userService.getUserById(anyLong())).thenReturn(user);

        mockMvc.perform(get("/api/users/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("username"))
                .andExpect(jsonPath("$.email").value("user@example.com"));
    }

    @Test
    @Order(24)
    public void CRUD_testGetAllUsers() throws Exception {
        User user = new User(1L, "username", "user@example.com");
        Mockito.when(userService.getAllUsers()).thenReturn(Collections.singletonList(user));

        mockMvc.perform(get("/api/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].username").value("username"))
                .andExpect(jsonPath("$[0].email").value("user@example.com"));
    }

    @Test
    @Order(25)
    public void CRUD_testUpdateUser() throws Exception {
        User user = new User(1L, "updatedUser", "updated@example.com");
        Mockito.when(userService.updateUser(anyLong(), any(User.class))).thenReturn(user);

        mockMvc.perform(put("/api/users/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(user)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("updatedUser"))
                .andExpect(jsonPath("$.email").value("updated@example.com"));
    }

    @Test
    @Order(26)
    public void CRUD_testDeleteUser() throws Exception {
        Mockito.doNothing().when(userService).deleteUser(anyLong());

        mockMvc.perform(delete("/api/users/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    @Order(27)
	void CRUD_testPathVariableAnnotations() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/controller/AdminController.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@PathVariable"), "Admin Controller should contain @PathVariable annotation");
	}

	@Test
    @Order(28)
	void CRUD_testRequestBodyAnnotations() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/controller/AdminController.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@RequestBody"), "Admin Controller should contain @RequestBody annotation");
	}

    @Test
    @Order(29)
    public void JPQL_testFindByEmail() {
        // Create and save a user
        User user1 = new User();
        user1.setUsername("John Doe");
        user1.setEmail("john.doe@example.com");
        userRepository.save(user1);

        // Search for the user's email
        List<User> result = userRepository.findByEmail("john.doe@example.com");

        // Assert the result is not empty and contains the correct user
        assertThat(result).isNotEmpty();
        assertThat(result.get(0).getUsername()).isEqualTo("John Doe");
    }

	@Test
    @Order(30)
    public void JPQL_testFindByEmailEmpty() {
        // Create and save a user
        User user1 = new User();
        user1.setUsername("John Doe");
        user1.setEmail("john.doe@example.com");
        userRepository.save(user1);

        // Search for a non-existent email
        List<User> result = userRepository.findByEmail("nonexistent@example.com");

        // Assert the result is empty
        assertThat(result).isEmpty();
    }

    @Test
    @Order(31)
	void PaginateSorting_testPaginateAdminControllers() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/controller/AdminController.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("Page<Admin>"), "Admin Controller should contain Page<Admin> ");
	}

	@Test
    @Order(32)
	void PaginateSorting_testPaginateAdminService() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/service/AdminService.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("Pageable"), "Admin Service should contain Pagable");
	}

	@Test
    @Order(33)
    void Mapping_testEntityHasOneToManyRelation() throws Exception {
        Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Admin.java");
        String entityFileContent = Files.readString(entityFilePath);
        assertTrue(entityFileContent.contains("@OneToMany"), "Entity should contain @OneToMany annotation");
    }

	@Test
    @Order(34)
	void Mapping_testEntityHasOneToOne() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Driver.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@OneToOne"), "Entity should contain @OneToOne annotation");
	}

	@Test
    @Order(35)
	void Mapping_testMemberHasOneToMany() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/User.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@OneToMany"), "Member entity should contain @OneToMany annotation");
	}

	@Test
    @Order(36)
	void Mapping_testBusHasColumn() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Bus.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@Column"), "Bus entity should contain @Column annotation");
	}

	@Test
    @Order(37)
	public void SwaggerUI_testConfigurationFolder() {
		String directoryPath = "src/main/java/com/example/demo/config";
		File directory = new File(directoryPath);
		assertTrue(directory.exists() && directory.isDirectory());
	}

	@Test
    @Order(38)
	void SwaggerUI_testSwaggerConfigFile() {
		String filePath = "src/main/java/com/example/demo/config/SwaggerConfig.java";
		File file = new File(filePath);
		assertTrue(file.exists() && file.isFile());

	}

	@Test
    @Order(39)
	public void LOG_testLogFolderAndFileCreation() {
		String LOG_FOLDER_PATH = "logs";
		String LOG_FILE_PATH = "logs/application.log";
		// Check if the "logs" folder exists
		File logFolder = new File(LOG_FOLDER_PATH);
		assertTrue(logFolder.exists(), "Log folder should be created");
		// Check if the "application.log" file exists inside the "logs" folder
		File logFile = new File(LOG_FILE_PATH);
		assertTrue(logFile.exists(), "Log file should be created inside 'logs' folder");
	}

	@Test
    @Order(40)
	void AOP_testAOPConfigFile() {
		String filePath = "src/main/java/com/example/demo/aspect/LoggingAspect.java";
		File file = new File(filePath);
		assertTrue(file.exists() && file.isFile());

	}

	@Test
    @Order(41)
	void AOP_testAOPConfigFileAspect() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/aspect/LoggingAspect.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("Aspect"), "Book entity should contain @RequestBody annotation");
	}

}
