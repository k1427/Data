package com.prjgrp.artf.Repository;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.prjgrp.artf.Model.Flight;

public interface FlightRepository extends JpaRepository<Flight, Long> {
    @Query("SELECT f FROM Flight f WHERE f.airlineName = :airlineName")
List<Flight> findByAirlineName(@Param("airlineName") String airlineName);

@Query("SELECT f FROM Flight f WHERE f.ticketPrice BETWEEN :minPrice AND :maxPrice")
List<Flight> findByTicketPriceBetween(@Param("minPrice") Double minPrice, @Param("maxPrice") Double maxPrice);

@Query("SELECT f FROM Flight f WHERE f.departureTime > :departureTime AND f.availableSeats >= :requiredSeats")
List<Flight> findAvailableFlights(@Param("departureTime") LocalDateTime departureTime, @Param("requiredSeats") Integer requiredSeats);

}
