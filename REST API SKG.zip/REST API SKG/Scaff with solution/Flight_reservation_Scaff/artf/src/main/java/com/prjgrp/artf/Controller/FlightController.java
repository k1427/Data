package com.prjgrp.artf.Controller;

import com.prjgrp.artf.Model.Flight;
import com.prjgrp.artf.Service.FlightService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/flights")
public class FlightController {

    private final FlightService flightService;

    @Autowired
    public FlightController(FlightService flightService) {
        this.flightService = flightService;
    }

    @PostMapping
    public ResponseEntity<Flight> create(@RequestBody Flight flight) {
        return new ResponseEntity<>(flightService.create(flight), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Flight>> findAll() {
        return new ResponseEntity<>(flightService.findAll(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Flight> findById(@PathVariable Long id) {
        return new ResponseEntity<>(flightService.findById(id), HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Flight> update(@PathVariable Long id, @RequestBody Flight updatedFlight) {
        return new ResponseEntity<>(flightService.update(id, updatedFlight), HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        flightService.delete(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
