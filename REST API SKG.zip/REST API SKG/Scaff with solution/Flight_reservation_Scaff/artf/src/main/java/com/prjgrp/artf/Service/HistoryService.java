package com.prjgrp.artf.Service;

import com.prjgrp.artf.Model.History;
import com.prjgrp.artf.Repository.HistoryRepository;
import com.prjgrp.artf.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class HistoryService {

    private final HistoryRepository historyRepository;

    @Autowired
    public HistoryService(HistoryRepository historyRepository) {
        this.historyRepository = historyRepository;
    }

    @Transactional
    public History create(History history) {
        if (history.getUser() == null || history.getFlight() == null) {
            throw new IllegalArgumentException("User and Flight details cannot be null");
        }
        return historyRepository.save(history);
    }

    @Transactional(readOnly = true)
    public List<History> findAll() {
        return historyRepository.findAll();
    }

    @Transactional(readOnly = true)
    public History findById(Long id) {
        return historyRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("History record not found for ID: " + id));
    }

    @Transactional
    public History update(Long id, History updatedHistory) {
        History existingHistory = findById(id);
        
        existingHistory.setUser(updatedHistory.getUser());
        existingHistory.setFlight(updatedHistory.getFlight());
        existingHistory.setBookingDate(updatedHistory.getBookingDate());
        existingHistory.setStatus(updatedHistory.getStatus());  // Correct field for status
        existingHistory.setAmountPaid(updatedHistory.getAmountPaid()); // Ensure amount is updated

        return historyRepository.save(existingHistory);
    }

    @Transactional
    public void delete(Long id) {
        History history = findById(id);
        historyRepository.delete(history);
    }
}
