package com.prjgrp.artf.aspect;

import com.prjgrp.artf.Model.History;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;

@Aspect
@Component
public class LoggingAspect {

    private static final Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

    // Define a pointcut for the create method in HistoryService
    @Pointcut("execution(* com.prjgrp.artf.Service.HistoryService.create(..))")
    public void createHistoryMethod() {}

    // Before advice: Executes before create method execution
    @Before("createHistoryMethod()")
    public void logBeforeCreate() {
        logger.info("Creating a new history record...");
    }

    // After returning advice: Executes after create method execution successfully
    @AfterReturning(pointcut = "createHistoryMethod()", returning = "result")
    public void logAfterCreate(Object result) {
        logger.info("Successfully created history record with ID: {}", ((History) result).getId());
    }

    // Define a pointcut for the findAll method in HistoryService
    @Pointcut("execution(* com.prjgrp.artf.Service.HistoryService.findAll(..))")
    public void findAllHistoryMethod() {}

    // Before advice: Executes before findAll method execution
    @Before("findAllHistoryMethod()")
    public void logBeforeFindAll() {
        logger.info("Fetching all history records...");
    }

    // After returning advice: Executes after findAll method execution successfully
    @AfterReturning(pointcut = "findAllHistoryMethod()", returning = "result")
    public void logAfterFindAll(Object result) {
        logger.info("Successfully fetched all history records, count: {}", ((List<?>) result).size());
    }

    // Define a pointcut for the findById method in HistoryService
    @Pointcut("execution(* com.prjgrp.artf.Service.HistoryService.findById(..))")
    public void findByIdHistoryMethod() {}

    // Before advice: Executes before findById method execution
    @Before("findByIdHistoryMethod()")
    public void logBeforeFindById() {
        logger.info("Fetching history record by ID...");
    }

    // After returning advice: Executes after findById method execution successfully
    @AfterReturning(pointcut = "findByIdHistoryMethod()", returning = "result")
    public void logAfterFindById(Object result) {
        if (result != null) {
            logger.info("Successfully fetched history record with ID: {}", ((History) result).getId());
        } else {
            logger.info("No history record found with the given ID.");
        }
    }

    // Define a pointcut for the update method in HistoryService
    @Pointcut("execution(* com.prjgrp.artf.Service.HistoryService.update(..))")
    public void updateHistoryMethod() {}

    // Before advice: Executes before update method execution
    @Before("updateHistoryMethod()")
    public void logBeforeUpdate() {
        logger.info("Updating history record...");
    }

    // After returning advice: Executes after update method execution successfully
    @AfterReturning(pointcut = "updateHistoryMethod()", returning = "result")
    public void logAfterUpdate(Object result) {
        logger.info("Successfully updated history record with ID: {}", ((History) result).getId());
    }

    // Define a pointcut for the delete method in HistoryService
    @Pointcut("execution(* com.prjgrp.artf.Service.HistoryService.delete(..))")
    public void deleteHistoryMethod() {}

    // Before advice: Executes before delete method execution
    @Before("deleteHistoryMethod()")
    public void logBeforeDelete() {
        logger.info("Deleting history record...");
    }

    // After returning advice: Executes after delete method execution successfully
    @AfterReturning(pointcut = "deleteHistoryMethod()")
    public void logAfterDelete() {
        logger.info("Successfully deleted a history record.");
    }

    
}
