package com.prjgrp.artf.Controller;

import com.prjgrp.artf.Model.History;
import com.prjgrp.artf.Service.HistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/histories")
public class HistoryController {

    private final HistoryService historyService;

    @Autowired
    public HistoryController(HistoryService historyService) {
        this.historyService = historyService;
    }

    @PostMapping
    public ResponseEntity<History> create(@RequestBody History history) {
        return new ResponseEntity<>(historyService.create(history), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<History>> findAll() {
        return new ResponseEntity<>(historyService.findAll(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<History> findById(@PathVariable Long id) {
        return new ResponseEntity<>(historyService.findById(id), HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<History> update(@PathVariable Long id, @RequestBody History updatedHistory) {
        return new ResponseEntity<>(historyService.update(id, updatedHistory), HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        historyService.delete(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
