package com.prjgrp.artf.Model;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@Entity
@Table(name = "history")
public class History {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private LocalDateTime bookingDate;

    @Column(nullable = false)
    private String status; // e.g., Completed, Canceled

    @Column(nullable = false)
    private Double amountPaid;

    // Many-to-One relationship with User
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    // Many-to-One relationship with Flight
    @JsonProperty("users")
    @ManyToOne
    @JoinColumn(name = "flight_id", nullable = false)
    private Flight flight;
}
