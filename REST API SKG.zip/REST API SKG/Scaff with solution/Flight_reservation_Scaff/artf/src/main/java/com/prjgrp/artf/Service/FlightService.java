package com.prjgrp.artf.Service;

import com.prjgrp.artf.Model.Flight;
import com.prjgrp.artf.Repository.FlightRepository;
import com.prjgrp.artf.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class FlightService {

    private final FlightRepository flightRepository;

    @Autowired
    public FlightService(FlightRepository flightRepository) {
        this.flightRepository = flightRepository;
    }

    @Transactional
    public Flight create(Flight flight) {
        return flightRepository.save(flight);
    }

    @Transactional(readOnly = true)
    public List<Flight> findAll() {
        return flightRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Flight findById(Long id) {
        return flightRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found for ID: " + id));
    }

    @Transactional
    public Flight update(Long id, Flight updatedFlight) {
        Flight existingFlight = findById(id);
        existingFlight.setFlightNumber(updatedFlight.getFlightNumber());
        existingFlight.setAirlineName(updatedFlight.getAirlineName());
        existingFlight.setDepartureLocation(updatedFlight.getDepartureLocation());
        existingFlight.setArrivalLocation(updatedFlight.getArrivalLocation());
        existingFlight.setDepartureTime(updatedFlight.getDepartureTime());
        existingFlight.setArrivalTime(updatedFlight.getArrivalTime());
        existingFlight.setTotalSeats(updatedFlight.getTotalSeats());
        existingFlight.setAvailableSeats(updatedFlight.getAvailableSeats());
        existingFlight.setTicketPrice(updatedFlight.getTicketPrice());
        return flightRepository.save(existingFlight);
    }

    @Transactional
    public void delete(Long id) {
        Flight flight = findById(id);
        flightRepository.delete(flight);
    }
}
