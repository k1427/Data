package com.rechargebackend.pulsetopupbackend.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rechargebackend.pulsetopupbackend.Model.User;

public interface UserRepository extends JpaRepository<User, Long> {}
