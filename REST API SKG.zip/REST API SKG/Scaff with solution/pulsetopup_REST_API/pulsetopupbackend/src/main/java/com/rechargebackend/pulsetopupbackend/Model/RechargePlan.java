package com.rechargebackend.pulsetopupbackend.Model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

import javax.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
public class RechargePlan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String planName;

    @Column(nullable = false)
    private String planDescription;

    @Column(nullable = false)
    private Integer planDuration;

    @Column(nullable = false)
    private Double price;

    // Many-to-many relationship with User (If needed)
    @JsonProperty("users") // Custom JSON Property name in response
    @ManyToMany(mappedBy = "rechargePlans")
    private List<User> users;
}
