package com.rechargebackend.pulsetopupbackend.Model;

import java.time.LocalDate;

import javax.persistence.*;

import lombok.Data;

@Data
@Entity
public class History {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "user_id", insertable = false, updatable = false)  // Mark as insertable and updatable false
    private Integer userId;  // Foreign key
    
    private String rechargePlan;
    private LocalDate date;
    private String time;
    
    // Define the Many-to-One relationship
    @ManyToOne
    @JoinColumn(name = "user_id")  // Foreign key column linking to the User entity
    private User user;
}
