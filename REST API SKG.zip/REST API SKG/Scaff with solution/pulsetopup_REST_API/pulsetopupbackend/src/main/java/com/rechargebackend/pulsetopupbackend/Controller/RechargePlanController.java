package com.rechargebackend.pulsetopupbackend.Controller;

import com.rechargebackend.pulsetopupbackend.Model.RechargePlan;
import com.rechargebackend.pulsetopupbackend.Service.RechargePlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/RechargePlan")
public class RechargePlanController {

    private final RechargePlanService rechargePlanService;

    @Autowired
    public RechargePlanController(RechargePlanService rechargePlanService) {
        this.rechargePlanService = rechargePlanService;
    }

    @PostMapping
    public ResponseEntity<RechargePlan> create(@RequestBody RechargePlan rechargePlan) {
        return new ResponseEntity<>(rechargePlanService.create(rechargePlan), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<RechargePlan>> findAll() {
        return new ResponseEntity<>(rechargePlanService.findAll(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<RechargePlan> findById(@PathVariable Long id) {
        return new ResponseEntity<>(rechargePlanService.findById(id), HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<RechargePlan> update(@PathVariable Long id, @RequestBody RechargePlan updatedRechargePlan) {
        return new ResponseEntity<>(rechargePlanService.update(id, updatedRechargePlan), HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        rechargePlanService.delete(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
