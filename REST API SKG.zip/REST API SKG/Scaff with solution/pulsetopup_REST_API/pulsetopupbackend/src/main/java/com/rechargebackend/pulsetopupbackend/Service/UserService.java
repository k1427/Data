package com.rechargebackend.pulsetopupbackend.Service;
import com.rechargebackend.pulsetopupbackend.Model.*;
import com.rechargebackend.pulsetopupbackend.Repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.*;


import java.util.List;
import java.util.Optional;
@Service
public class UserService {
    
    @Autowired
    private UserRepository userRepository;

 
    public User createUser(User user) {
        return userRepository.save(user);
    }

    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

  
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

   
    public Optional<User> updateUser(Long id, User user) {
        if (userRepository.existsById(id)) {
            user.setId(id);  // Ensure ID is set for update
            return Optional.of(userRepository.save(user));
        } else {
            return Optional.empty();
        }
    }

    public Page<User> getAllUsersPaginateAndSort(int page, int size, String sortBy, String sortOrder) {
        Sort.Direction direction = Sort.Direction.ASC;
        if ("desc".equalsIgnoreCase(sortOrder)) {
            direction = Sort.Direction.DESC;
        }
        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sortBy));
        return userRepository.findAll(pageable);
    }

    
    public boolean deleteUser(Long id) {
        if (userRepository.existsById(id)) {
            userRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }

}
