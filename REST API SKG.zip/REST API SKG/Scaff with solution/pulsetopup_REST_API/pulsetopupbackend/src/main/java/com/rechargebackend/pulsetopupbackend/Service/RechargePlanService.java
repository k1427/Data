package com.rechargebackend.pulsetopupbackend.Service;

import com.rechargebackend.pulsetopupbackend.Model.RechargePlan;
import com.rechargebackend.pulsetopupbackend.Repository.RechargePlanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RechargePlanService {

    private final RechargePlanRepository rechargePlanRepository;

    @Autowired
    public RechargePlanService(RechargePlanRepository rechargePlanRepository) {
        this.rechargePlanRepository = rechargePlanRepository;
    }

    public RechargePlan create(RechargePlan rechargePlan) {
        return rechargePlanRepository.save(rechargePlan);
    }

    public List<RechargePlan> findAll() {
        return rechargePlanRepository.findAll();
    }

    public RechargePlan findById(Long id) {
        return rechargePlanRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Recharge plan not found for ID: " + id));
    }

    public RechargePlan update(Long id, RechargePlan updatedRechargePlan) {
        RechargePlan existingRechargePlan = findById(id);
        existingRechargePlan.setPlanName(updatedRechargePlan.getPlanName());
        existingRechargePlan.setPlanDescription(updatedRechargePlan.getPlanDescription());
        existingRechargePlan.setPlanDuration(updatedRechargePlan.getPlanDuration());
        existingRechargePlan.setPrice(updatedRechargePlan.getPrice());
        return rechargePlanRepository.save(existingRechargePlan);
    }

    public void delete(Long id) {
        RechargePlan rechargePlan = findById(id);
        rechargePlanRepository.delete(rechargePlan);
    }
}
