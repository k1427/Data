package com.rechargebackend.pulsetopupbackend.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String email;

    @Column(length = 100)
    private String firstName;

    @Column(length = 100)
    private String lastName;

    @Column(length = 15)
    private String phoneNumber;

    @Column(length = 255)
    private String address;

    // One-to-many relationship with History (User can have multiple History records)
    @JsonIgnore  // Prevents circular reference during JSON serialization
    @OneToMany(mappedBy = "user")
    private List<History> histories;

    // Many-to-many relationship with RechargePlan (if applicable)
    @JsonProperty("rechargePlans") // Custom JSON Property name in response
    @ManyToMany
    @JoinTable(
        name = "user_recharge_plans",
        joinColumns = @JoinColumn(name = "user_id"),
        inverseJoinColumns = @JoinColumn(name = "recharge_plan_id")
    )
    private List<RechargePlan> rechargePlans;
}
