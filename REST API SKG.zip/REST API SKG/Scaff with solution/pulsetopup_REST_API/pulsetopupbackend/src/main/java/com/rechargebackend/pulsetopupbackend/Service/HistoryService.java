package com.rechargebackend.pulsetopupbackend.Service;

import com.rechargebackend.pulsetopupbackend.Model.History;
import com.rechargebackend.pulsetopupbackend.Repository.HistoryRepository;
import com.rechargebackend.pulsetopupbackend.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class HistoryService {

    private final HistoryRepository historyRepository;

    @Autowired
    public HistoryService(HistoryRepository historyRepository) {
        this.historyRepository = historyRepository;
    }

    @Transactional
    public History create(History history) {
        if (history.getUser() == null) {
            throw new IllegalArgumentException("User cannot be null");
        }
        return historyRepository.save(history);
    }

    @Transactional(readOnly = true)
    public List<History> findAll() {
        return historyRepository.findAll();
    }

    @Transactional(readOnly = true)
    public History findById(Long id) {
        return historyRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("History record not found for ID: " + id));
    }

    @Transactional
    public History update(Long id, History updatedHistory) {
        History existingHistory = findById(id);
        existingHistory.setUser(updatedHistory.getUser());
        existingHistory.setRechargePlan(updatedHistory.getRechargePlan());
        existingHistory.setDate(updatedHistory.getDate());
        existingHistory.setTime(updatedHistory.getTime());
        return historyRepository.save(existingHistory);
    }

    @Transactional
    public void delete(Long id) {
        History history = findById(id);
        historyRepository.delete(history);
    }
}
