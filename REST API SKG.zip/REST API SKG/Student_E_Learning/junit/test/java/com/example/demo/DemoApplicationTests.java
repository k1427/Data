package com.example.demo;

import com.example.demo.entity.Student;
import com.example.demo.entity.Course;
import com.example.demo.service.StudentService;
import com.example.demo.service.CourseService;
import com.example.demo.entity.Trainer;
import com.example.demo.service.TrainerService;
import com.example.demo.service.UserService;
import com.example.demo.entity.User;
import com.example.demo.repository.CourseRepository;
import com.example.demo.repository.TrainerRepository;
import com.example.demo.repository.UserRepository; 
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

@AutoConfigureMockMvc
@TestMethodOrder(OrderAnnotation.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class DemoApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private StudentService studentService;

	@MockBean
	private CourseService courseService;

	@MockBean
	private TrainerService trainerService;

	@MockBean
	private UserService userService;

	@Autowired
	private TrainerRepository trainerRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private CourseRepository courseRepository;

    @BeforeEach
    void setUp() {
        // Set up User test data
        User user1 = new User(null, "John Doe", "john.doe@example.com");
        User user2 = new User(null, "Jane Smith", "jane.smith@example.com");
        userRepository.saveAll(List.of(user1, user2));

       // Set up Course test data
	   Course course1 = new Course();
	   course1.setTitle("Java Programming");
	   course1.setDescription("Learn Java from scratch.");
	   course1.setInstructor("John Doe");

	   Course course2 = new Course();
	   course2.setTitle("Python Programming");
	   course2.setDescription("Master Python programming.");
	   course2.setInstructor("Jane Doe");

	   courseRepository.saveAll(List.of(course1, course2));

	   // Set up Trainer test data
	   Trainer trainer1 = new Trainer();
	   trainer1.setTrainerName("Alice");
	   trainer1.setEmail("alice@example.com");
	   trainer1.setCourse(course1);

	   Trainer trainer2 = new Trainer();
	   trainer2.setTrainerName("Bob");
	   trainer2.setEmail("bob@example.com");
	   trainer2.setCourse(course2);

	   trainerRepository.saveAll(List.of(trainer1, trainer2));
    }
    
    @Order(1)
	@Test
	void contextLoads() {
	}

    @Test
    @Order(2)
	void Annotation_testStudentHasLombokAnnotations() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Student.java");
		String entityFileContent = Files.readString(entityFilePath);		
		assertTrue(entityFileContent.contains("@Data"), "Student entity should contain @Data annotation");
		assertTrue(entityFileContent.contains("@NoArgsConstructor"),
				"Student entity should contain @NoArgsConstructor annotation");
	}


	@Test
    @Order(3)
	void Annotation_testCourseHasLombokAnnotations() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Course.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@Data"), "Course entity should contain @Data annotation");
	}


	@Test
    @Order(4)
	void Annotation_testStudentHasJSONIgnoreAnnotations() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Student.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@JsonIgnore"), "Student entity should contain @JsonIgnore annotation");
	}


	@Test
    @Order(5)
	void Annotation_testUserHasJSONIgnoreAnnotations() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/User.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@JsonIgnore"), "User entity should contain @JsonIgnore annotation");
	}

    @Test
    @Order(6)
	void Repository_testStudentRepository() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/repository/StudentRepository.java");
		assertTrue(Files.exists(entityFilePath), "StudentRepository file should exist");
	}


	@Test
    @Order(7)
	void Repository_testCourseRepository() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/repository/CourseRepository.java");
		assertTrue(Files.exists(entityFilePath), "Course Repository file should exist");
	}


	@Test
    @Order(8)
	void Repository_testTrainerRepository() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/repository/TrainerRepository.java");
		assertTrue(Files.exists(entityFilePath), "Trainer Repository file should exist");
	}


	@Test
    @Order(9)
	void Repository_testUserRepository() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/repository/UserRepository.java");
		assertTrue(Files.exists(entityFilePath), "User Repository file should exist");
	}


    @Order(10)
    @Test
    void CRUD_testGetAllStudents() throws Exception {
        List<Student> students = Arrays.asList(
                new Student(1L, "Student One", "student.one@example.com"),
                new Student(2L, "Student Two", "student.two@example.com")
        );
        when(studentService.getAllStudents()).thenReturn(students);
        mockMvc.perform(get("/api/students"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(students.size()))
                .andExpect(jsonPath("$[0].name").value("Student One"))
                .andExpect(jsonPath("$[1].email").value("student.two@example.com"));

        verify(studentService, times(1)).getAllStudents();
    }

    
    @Test
    @Order(11)
    void CRUD_testGetStudentById() throws Exception {
        Long studentId = 1L;
        Student student = new Student(studentId, "Student One", "student.one@example.com");

        when(studentService.getStudentById(studentId)).thenReturn(student);

        mockMvc.perform(get("/api/students/{id}", studentId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Student One"))
                .andExpect(jsonPath("$.email").value("student.one@example.com"));

        verify(studentService, times(1)).getStudentById(studentId);
    }


    @Test
    @Order(12)
    void CRUD_testCreateStudent() throws Exception {
        Student student = new Student(null, "Student One", "student.one@example.com");
        Student savedStudent = new Student(1L, "Student One", "student.one@example.com");

        when(studentService.createStudent(Mockito.any(Student.class))).thenReturn(savedStudent);

        mockMvc.perform(post("/api/students")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(student)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(savedStudent.getId()))
                .andExpect(jsonPath("$.name").value(savedStudent.getName()))
                .andExpect(jsonPath("$.email").value(savedStudent.getEmail()));

        verify(studentService, times(1)).createStudent(Mockito.any(Student.class));
    }

   
    @Test
    @Order(13)
    void CRUD_testDeleteStudent() throws Exception {
        Long studentId = 1L;

        doNothing().when(studentService).deleteStudent(studentId);

        mockMvc.perform(delete("/api/students/{id}", studentId))
                .andExpect(status().isOk());

        verify(studentService, times(1)).deleteStudent(studentId);
    }

    @Test
    @Order(14)
    void CRUD_testGetAllCourses() throws Exception {
        // Initialize course list
        List<Course> courses = new ArrayList<>();

        // Create and set properties for the first course
        Course course1 = new Course();
        course1.setTitle("Course One");
        course1.setDescription("Description One");
        course1.setInstructor("Instructor One");

        // Create and set properties for the second course
        Course course2 = new Course();
        course2.setTitle("Course Two");
        course2.setDescription("Description Two");
        course2.setInstructor("Instructor Two");

        // Add courses to the list
        courses.add(course1);
        courses.add(course2);

        // Mock the courseService.getAllCourses() method to return the courses list
        when(courseService.getAllCourses()).thenReturn(courses);

        // Perform the GET request to /api/courses and verify the response
        mockMvc.perform(get("/api/courses"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(courses.size())) // Verify the length of the array
                .andExpect(jsonPath("$[0].title").value("Course One")) // Verify the title of the first course
                .andExpect(jsonPath("$[1].title").value("Course Two")); // Verify the title of the second course

        // Verify that the getAllCourses method was called exactly once
        verify(courseService, times(1)).getAllCourses();
    }

    
    @Test
    @Order(15)
    void CRUD_testCreateCourse() throws Exception {
        // Creating a Course instance
        Course course = new Course();
        course.setTitle("Course One");
        course.setDescription("Description One");
        course.setInstructor("Instructor One");

        // Creating a Course instance with ID (for comparison after saving)
        Course savedCourse = new Course();
        savedCourse.setId(1L); // Assuming the ID will be 1 after save
        savedCourse.setTitle("Course One");
        savedCourse.setDescription("Description One");
        savedCourse.setInstructor("Instructor One");

        // Mock the CourseService to return the savedCourse when the createCourse method is called
        when(courseService.createCourse(Mockito.any(Course.class))).thenReturn(savedCourse);

        // Perform the POST request to create a course and verify the response
        mockMvc.perform(post("/api/courses")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(course))) // Convert the Course object
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value(savedCourse.getTitle())) // Verify the title
                .andExpect(jsonPath("$.description").value(savedCourse.getDescription())) // Verify the description
                .andExpect(jsonPath("$.instructor").value(savedCourse.getInstructor())); // Verify the instructor

        // Verify that the createCourse method was called exactly once
        verify(courseService, times(1)).createCourse(Mockito.any(Course.class));
    }

    
    @Test
    @Order(16)
    void CRUD_testDeleteCourse() throws Exception {
        Long courseId = 1L;

        doNothing().when(courseService).deleteCourse(courseId);

        mockMvc.perform(delete("/api/courses/{id}", courseId))
                .andExpect(status().isOk());

        verify(courseService, times(1)).deleteCourse(courseId);
    }
    

    @Test
    @Order(17)
    void CRUD_testGetAllTrainers() throws Exception {
        // Initialize Trainer instances
        Trainer trainer1 = new Trainer();
        trainer1.setId(1L);
        trainer1.setTrainerName("Trainer One");
        trainer1.setEmail("trainerone@example.com");

        Trainer trainer2 = new Trainer();
        trainer2.setId(2L);
        trainer2.setTrainerName("Trainer Two");
        trainer2.setEmail("trainertwo@example.com");

        List<Trainer> trainers = Arrays.asList(trainer1, trainer2);

        // Mock the service to return the trainers
        when(trainerService.getAllTrainers()).thenReturn(trainers);

        // Perform the GET request to /api/trainers and verify the response
        mockMvc.perform(get("/api/trainers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(trainers.size())) // Verify the length of the list
                .andExpect(jsonPath("$[0].trainerName").value("Trainer One")) // Verify the first trainer's name
                .andExpect(jsonPath("$[1].trainerName").value("Trainer Two")) // Verify the second trainer's name
                .andExpect(jsonPath("$[0].email").value("trainerone@example.com")) // Verify the first trainer's email
                .andExpect(jsonPath("$[1].email").value("trainertwo@example.com")); // Verify the second trainer's email

        // Verify that the service method was called exactly once
        verify(trainerService, times(1)).getAllTrainers();
    }


    @Test
    @Order(18)
    void CRUD_testCreateTrainer() throws Exception {
        // Initialize Trainer instance
        Trainer trainer = new Trainer();
        trainer.setId(1L);
        trainer.setTrainerName("Trainer One");
        trainer.setEmail("trainerone@example.com");

        // Mock the service to save the trainer
        when(trainerService.createTrainer(any(Trainer.class))).thenReturn(trainer);

        // Perform the POST request to /api/trainers and verify the response
        mockMvc.perform(post("/api/trainers")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"trainerName\":\"Trainer One\",\"email\":\"trainerone@example.com\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.trainerName").value("Trainer One")) // Verify the trainer's name
                .andExpect(jsonPath("$.email").value("trainerone@example.com")); // Verify the trainer's email

        // Verify that the service method was called exactly once
        verify(trainerService, times(1)).createTrainer(any(Trainer.class));
    }


    @Test
    @Order(19)
    void CRUD_testDeleteTrainer() throws Exception {
        Long trainerId = 1L;

        // Mock the service call
        doNothing().when(trainerService).deleteTrainer(trainerId);

        // Perform DELETE request and verify the response
        mockMvc.perform(delete("/api/trainers/{id}", trainerId))
                .andExpect(status().isOk());

        // Verify that the service method was called exactly once
        verify(trainerService, times(1)).deleteTrainer(trainerId);
    }


    @Test
    @Order(20)
    public void CRUD_testCreateUser() throws Exception {
        User user = new User(1L, "username", "user@example.com");
        Mockito.when(userService.createUser(any(User.class))).thenReturn(user);
 
        mockMvc.perform(post("/api/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(user)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("username"))
                .andExpect(jsonPath("$.email").value("user@example.com"));
    }
 
    @Test
    @Order(21)
    public void CRUD_testGetUserById() throws Exception {
        User user = new User(1L, "username", "user@example.com");
        Mockito.when(userService.getUserById(anyLong())).thenReturn(user);
 
        mockMvc.perform(get("/api/users/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("username"))
                .andExpect(jsonPath("$.email").value("user@example.com"));
    }
 
    @Test
    @Order(22)
    public void CRUD_testGetAllUsers() throws Exception {
        User user = new User(1L, "username", "user@example.com");
        Mockito.when(userService.getAllUsers()).thenReturn(Collections.singletonList(user));
 
        mockMvc.perform(get("/api/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].username").value("username"))
                .andExpect(jsonPath("$[0].email").value("user@example.com"));
    }
 
    @Test
    @Order(23)
    public void CRUD_testUpdateUser() throws Exception {
        User user = new User(1L, "updatedUser", "updated@example.com");
        Mockito.when(userService.updateUser(anyLong(), any(User.class))).thenReturn(user);
 
        mockMvc.perform(put("/api/users/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(user)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("updatedUser"))
                .andExpect(jsonPath("$.email").value("updated@example.com"));
    }
 
    @Test
    @Order(24)
    public void CRUD_testDeleteUser() throws Exception {
        Mockito.doNothing().when(userService).deleteUser(anyLong());
 
        mockMvc.perform(delete("/api/users/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    @Order(25)
	void CRUD_testPathVariableAnnotations() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/controller/StudentController.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@PathVariable"), "StudentController entity should contain @PathVariable annotation");
	}

	@Test
    @Order(26)
	void CRUD_testRequestBodyAnnotations() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/controller/StudentController.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@RequestBody"), "StudentController entity should contain @RequestBody annotation");
	}

	@Test
	@Order(27)
    void JPQL_testQueryExistsAndExecutes() {
        // Check if the query executes without throwing exceptions
        assertDoesNotThrow(() -> {
            List<User> users = userRepository.findByEmail("john.doe@example.com");
            assertThat(users).isNotNull(); // Ensure the query returns a result (could be empty but not null)
        });
    }

    @Test
	@Order(28)
    void JPQL_testFindByEmailUserNoResult() {
        List<User> users = userRepository.findByEmail("not.exist@example.com");
        assertThat(users).isEmpty();
    }
	
	@Test
	@Order(29)
	void PaginateSorting_testPaginateStudentsControllers() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/controller/StudentController.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("Page<Student>"), "StudentController entity should contain @Page annotation");
	}


	@Test
	@Order(30)
	void PaginateSorting_testPaginateStudentsService() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/service/StudentService.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("Pageable"), "StudentService entity should contain Pageable annotation");
	}
    
	@Test
    @Order(31)
	void Mapping_testEntityHasOneToManyRelation() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Student.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@OneToMany"), "Entity should contain @OneToMany annotation");
 	}


	@Test
	@Order(32)
	void Mapping_testEntityHasJoinTable() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Trainer.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@JoinTable"), "Entity should contain @JoinTable annotation");
	}

	@Test
	@Order(33)
	void Mapping_testEntityHasManyToMany() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Trainer.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@ManyToMany"), "Entity should contain @ManyToMany annotation");
	}

	@Test
	@Order(34)
	void Mapping_testUserHasOneToMany() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/User.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@OneToMany"), "User entity should contain @OneToMany annotation");
	}

	@Test
	@Order(35)
	void Mapping_testCourseHasColumn() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Course.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@Column"), "Course entity should contain @Column annotation");
	}


	@Test
	@Order(36)
	void Mapping_testStudentHasOneToMany() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Student.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@OneToMany"), "Student entity should contain @OneToMany annotation");
	}

	

	@Test
	@Order(37)
	public void SwaggerUI_testConfigurationFolder() {
		String directoryPath = "src/main/java/com/example/demo/config"; 
		File directory = new File(directoryPath);
		assertTrue(directory.exists() && directory.isDirectory());
	}


	@Test
	@Order(38)
	void SwaggerUI_testSwaggerConfigFile() {
		String filePath = "src/main/java/com/example/demo/config/SwaggerConfig.java";
		File file = new File(filePath);
		assertTrue(file.exists() && file.isFile());

	}

	@Test
	@Order(39)
	public void LOG_testLogFolderAndFileCreation() {
		String LOG_FOLDER_PATH = "logs";
		String LOG_FILE_PATH = "logs/application.log";
		// Check if the "logs" folder exists
		File logFolder = new File(LOG_FOLDER_PATH);
		assertTrue(logFolder.exists(), "Log folder should be created");
		// Check if the "application.log" file exists inside the "logs" folder
		File logFile = new File(LOG_FILE_PATH);
		assertTrue(logFile.exists(), "Log file should be created inside 'logs' folder");
	}

	@Test
	@Order(40)
	void AOP_testAOPConfigFile() {
		String filePath = "src/main/java/com/example/demo/aspect/LoggingAspect.java";		
		File file = new File(filePath);
		assertTrue(file.exists() && file.isFile());

	}

	@Test
	@Order(41)
	void AOP_testAOPConfigFileAspect() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/aspect/LoggingAspect.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("Aspect"), "Book entity should contain @RequestBody annotation");
	}

}
