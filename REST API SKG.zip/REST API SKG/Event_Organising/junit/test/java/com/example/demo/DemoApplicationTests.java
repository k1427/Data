package com.example.demo;

import com.example.demo.entity.Organizer;
import com.example.demo.entity.Event;
import com.example.demo.service.OrganizerService;
import com.example.demo.service.EventService;
import com.example.demo.entity.Venue;
import com.example.demo.service.VenueService;
import com.example.demo.service.UserService;
import com.example.demo.entity.User;
import com.example.demo.entity.Organizer;
import com.example.demo.repository.EventRepository;
import com.example.demo.repository.VenueRepository;
import com.example.demo.repository.UserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import static org.assertj.core.api.Assertions.assertThat;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@AutoConfigureMockMvc
@TestMethodOrder(OrderAnnotation.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class DemoApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private OrganizerService organizerService;

	public OrganizerService getOrganizerService() {
		return organizerService;
	}

	public void setOrganizerService(OrganizerService organizerService) {
		this.organizerService = organizerService;
	}

	@MockBean
	private EventService eventService;

	@MockBean
	private VenueService venueService;

	@MockBean
	private UserService userService;

	@Autowired
	private VenueRepository venueRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private EventRepository eventRepository;

    private ObjectMapper objectMapper = new ObjectMapper();  // Jackson ObjectMapper for JSON conversion

	@Order(1)
	@Test
	void contextLoads() {
	}

	@Test
	@Order(2)
	void Annotation_testOrganizerHasLombokAnnotations() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Organizer.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@Data"), "Organizer entity should contain @Data annotation");
		assertTrue(entityFileContent.contains("@NoArgsConstructor"),
				"Author entity should contain @NoArgsConstructor annotation");
	}


	@Test
	@Order(3)
	void Annotation_testEventHasLombokAnnotations() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Event.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@Data"), "Event entity should contain @Data annotation");
	}


	@Test
	@Order(4)
	void Annotation_testOrganizerHasJSONIgnoreAnnotations() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Organizer.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@JsonIgnore"), "Organizer entity should contain @JsonIgnore annotation");
	}

	@Test
	@Order(5)
	void Annotation_testUserHasJSONIgnoreAnnotations() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/User.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@JsonIgnore"), "User entity should contain @JsonIgnore annotation");
	}

	@Test
	@Order(6)
	void Repository_testOrganizerRepository() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/repository/OrganizerRepository.java");
		assertTrue(Files.exists(entityFilePath), "OrganizerRepository file should exist");
	}

	@Test
	@Order(7)
	void Repository_testEventRepository() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/repository/EventRepository.java");
		assertTrue(Files.exists(entityFilePath), "Event Repository file should exist");
	}


	@Test
	@Order(8)
	void Repository_testVenueRepository() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/repository/VenueRepository.java");
		assertTrue(Files.exists(entityFilePath), "Venue Repository file should exist");
	}


	@Test
	@Order(9)
	void Repository_testUserRepository() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/repository/UserRepository.java");
		assertTrue(Files.exists(entityFilePath), "User Repository file should exist");
	}

    @Test
	@Order(10)
    void CRUD_testGetAllOrganizers() throws Exception {
        List<Organizer> organizers = Arrays.asList(
                new Organizer(1L, "Organizer One"),
                new Organizer(2L, "Organizer Two")
        );

        when(organizerService.getAllOrganizers()).thenReturn(organizers);

        mockMvc.perform(get("/api/organizers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(organizers.size()))
                .andExpect(jsonPath("$[0].name").value("Organizer One"))
                .andExpect(jsonPath("$[1].name").value("Organizer Two"));

        verify(organizerService, times(1)).getAllOrganizers();
    }

    @Test
	@Order(11)
    void CRUD_testGetOrganizerById() throws Exception {
        Long organizerId = 1L;
        Organizer organizer = new Organizer(organizerId, "Organizer One");

        when(organizerService.getOrganizerById(organizerId)).thenReturn(organizer);

        mockMvc.perform(get("/api/organizers/{id}", organizerId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Organizer One"));

        verify(organizerService, times(1)).getOrganizerById(organizerId);
    }

    @Test
	@Order(12)
    void CRUD_testCreateOrganizer() throws Exception {
        Organizer organizer = new Organizer(null, "Organizer One");
        Organizer savedOrganizer = new Organizer(1L, "Organizer One");

        when(organizerService.createOrganizer(Mockito.any(Organizer.class))).thenReturn(savedOrganizer);

        mockMvc.perform(post("/api/organizers")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(organizer)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(savedOrganizer.getId()))
                .andExpect(jsonPath("$.name").value(savedOrganizer.getName()));

        verify(organizerService, times(1)).createOrganizer(Mockito.any(Organizer.class));
    }

    @Test
	@Order(13)
    void CRUD_testDeleteOrganizer() throws Exception {
        Long organizerId = 1L;

        doNothing().when(organizerService).deleteOrganizer(organizerId);

        mockMvc.perform(delete("/api/organizers/{id}", organizerId))
                .andExpect(status().isOk());

        verify(organizerService, times(1)).deleteOrganizer(organizerId);
    }

	@Test
	@Order(14)
    public void CRUD_testCreateEvent() throws Exception {
        Event event = new Event(1L, "Concert", "Stadium", "2024-10-15", "18:00", 100);
        Mockito.when(eventService.createEvent(any(Event.class))).thenReturn(event);

        mockMvc.perform(post("/api/events")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(event)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.eventName").value("Concert"))
                .andExpect(jsonPath("$.location").value("Stadium"))
                .andExpect(jsonPath("$.date").value("2024-10-15"))
                .andExpect(jsonPath("$.time").value("18:00"))
                .andExpect(jsonPath("$.availableSeats").value(100));
    }

    @Test
	@Order(15)
    public void CRUD_testGetEventById() throws Exception {
        Event event = new Event(1L, "Concert", "Stadium", "2024-10-15", "18:00", 100);
        Mockito.when(eventService.getEventById(anyLong())).thenReturn(event);

        mockMvc.perform(get("/api/events/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.eventName").value("Concert"))
                .andExpect(jsonPath("$.location").value("Stadium"))
                .andExpect(jsonPath("$.date").value("2024-10-15"))
                .andExpect(jsonPath("$.time").value("18:00"))
                .andExpect(jsonPath("$.availableSeats").value(100));
    }

    @Test
	@Order(16)
    public void CRUD_testUpdateEvent() throws Exception {
        Event event = new Event(1L, "Updated Concert", "Updated Stadium", "2024-10-16", "19:00", 150);
        Mockito.when(eventService.updateEvent(anyLong(), any(Event.class))).thenReturn(event);

        mockMvc.perform(put("/api/events/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(event)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.eventName").value("Updated Concert"))
                .andExpect(jsonPath("$.location").value("Updated Stadium"))
                .andExpect(jsonPath("$.date").value("2024-10-16"))
                .andExpect(jsonPath("$.time").value("19:00"))
                .andExpect(jsonPath("$.availableSeats").value(150));
    }

    @Test
	@Order(17)
    public void CRUD_testDeleteEvent() throws Exception {
        Mockito.doNothing().when(eventService).deleteEvent(anyLong());

        mockMvc.perform(delete("/api/events/1"))
                .andExpect(status().isNoContent());
    }

	@Test
	@Order(18)
    public void CRUD_testCreateUser() throws Exception {
        User user = new User(1L, "username", "user@example.com");
        Mockito.when(userService.createUser(any(User.class))).thenReturn(user);

        mockMvc.perform(post("/api/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(user)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("username"))
                .andExpect(jsonPath("$.email").value("user@example.com"));
    }

    @Test
	@Order(19)
    public void CRUD_testGetUserById() throws Exception {
        User user = new User(1L, "username", "user@example.com");
        Mockito.when(userService.getUserById(anyLong())).thenReturn(user);

        mockMvc.perform(get("/api/users/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("username"))
                .andExpect(jsonPath("$.email").value("user@example.com"));
    }

    @Test
	@Order(20)
    public void CRUD_testGetAllUsers() throws Exception {
        User user = new User(1L, "username", "user@example.com");
        Mockito.when(userService.getAllUsers()).thenReturn(Collections.singletonList(user));

        mockMvc.perform(get("/api/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].username").value("username"))
                .andExpect(jsonPath("$[0].email").value("user@example.com"));
    }

    @Test
	@Order(21)
    public void CRUD_testUpdateUser() throws Exception {
        User user = new User(1L, "updatedUser", "updated@example.com");
        Mockito.when(userService.updateUser(anyLong(), any(User.class))).thenReturn(user);

        mockMvc.perform(put("/api/users/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(user)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("updatedUser"))
                .andExpect(jsonPath("$.email").value("updated@example.com"));
    }

    @Test
	@Order(22)
    public void CRUD_testDeleteUser() throws Exception {
        Mockito.doNothing().when(userService).deleteUser(anyLong());

        mockMvc.perform(delete("/api/users/1"))
                .andExpect(status().isNoContent());
    }


	//CRUD for Venue
	@Test
	@Order(23)
    public void CRUD_testCreateVenue() throws Exception {
        Venue venue = new Venue(1L, "Conference Hall", "123 Main St", 200);
        Mockito.when(venueService.createVenue(any(Venue.class))).thenReturn(venue);

        mockMvc.perform(post("/api/venues")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(venue)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.name").value("Conference Hall"))
                .andExpect(jsonPath("$.location").value("123 Main St"))
                .andExpect(jsonPath("$.capacity").value(200));
    }

    @Test
	@Order(24)
    public void CRUD_testGetVenueById() throws Exception {
        Venue venue = new Venue(1L, "Conference Hall", "123 Main St", 200);
        Mockito.when(venueService.getVenueById(anyLong())).thenReturn(venue);

        mockMvc.perform(get("/api/venues/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.name").value("Conference Hall"))
                .andExpect(jsonPath("$.location").value("123 Main St"))
                .andExpect(jsonPath("$.capacity").value(200));
    }

    @Test
	@Order(25)
    public void CRUD_testGetAll_Venues() throws Exception {
        Venue venue = new Venue(1L, "Conference Hall", "123 Main St", 200);
        Mockito.when(venueService.getAllVenues()).thenReturn(Collections.singletonList(venue));

        mockMvc.perform(get("/api/venues"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].name").value("Conference Hall"))
                .andExpect(jsonPath("$[0].location").value("123 Main St"))
                .andExpect(jsonPath("$[0].capacity").value(200));
    }

    @Test
	@Order(26)
    public void CRUD_testUpdateVenue() throws Exception {
        Venue venue = new Venue(1L, "Updated Conference Hall", "456 Main St", 300);
        Mockito.when(venueService.updateVenue(anyLong(), any(Venue.class))).thenReturn(venue);

        mockMvc.perform(put("/api/venues/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(venue)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.name").value("Updated Conference Hall"))
                .andExpect(jsonPath("$.location").value("456 Main St"))
                .andExpect(jsonPath("$.capacity").value(300));
    }

    @Test
	@Order(27)
    public void CRUD_testDeleteVenue() throws Exception {
        Mockito.doNothing().when(venueService).deleteVenue(anyLong());

        mockMvc.perform(delete("/api/venues/1"))
                .andExpect(status().isNoContent());
    }

	@Test
	@Order(28)
	void CRUD_testPathVariableAnnotations() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/controller/OrganizerController.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@PathVariable"), "OrganizerController entity should contain @PathVariable annotation");
	}

	@Test
	@Order(29)
	void CRUD_testRequestBodyAnnotations() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/controller/OrganizerController.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@RequestBody"), "OrganizerController should contain @RequestBody annotation");
	}

	@Test
	@Order(30)
    public void JPQL_testFindByEmailEmpty() {
        User user1 = new User();
        user1.setUsername("John Doe");
        user1.setEmail("john.doe@example.com");
        userRepository.save(user1);
        List<User> result = userRepository.findByEmail("nonexistent@example.com");
        assertThat(result).isEmpty();
    }

	@Test
	@Order(31)
    public void JPQL_testFindByEmail() {
        User user1 = new User();
        user1.setUsername("John Doe");
        user1.setEmail("john.doe@example.com");
        userRepository.save(user1);
        List<User> result = userRepository.findByEmail("john.doe@example.com");
        assertThat(result).isNotEmpty();
        assertThat(result.get(0).getUsername()).isEqualTo("John Doe");
    }

	@Test
	@Order(32)
	void PaginateSorting_testPaginateOrganizerController() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/controller/OrganizerController.java");

		String entityFileContent = Files.readString(entityFilePath);

		assertTrue(entityFileContent.contains("Page<Organizer>"));
	}


	@Test
	@Order(33)
	void PaginateSorting_testPaginateOrganizerService() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/service/OrganizerService.java");

		String entityFileContent = Files.readString(entityFilePath);

		assertTrue(entityFileContent.contains("Pageable"), "Book entity should contain @RequestBody annotation");
	}

	@Test
	@Order(34)
    	public void PaginateSorting_testGetAllEventsWithPagination() throws Exception {
        Event event1 = new Event(1L, "Event One", "Location One", "2025-01-01", "10:00 AM", 100);
        Event event2 = new Event(2L, "Event Two", "Location Two", "2025-01-02", "11:00 AM", 200);

        List<Event> events = List.of(event1, event2);
        Page<Event> eventPage = new PageImpl<>(events, Pageable.ofSize(2), events.size());

        Mockito.when(eventService.getAllEvents(any(Pageable.class))).thenReturn(eventPage);

        mockMvc.perform(get("/api/events?page=0&size=2&sortBy=date,asc"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content.length()").value(2))
                .andExpect(jsonPath("$.content[0].eventName").value("Event One"))
                .andExpect(jsonPath("$.content[1].eventName").value("Event Two"));
    }

	@Test
	@Order(35)
	void Mapping_testEntityHasOneToManyRelation() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Organizer.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@OneToMany"), "Entity should contain @OneToMany annotation");
	}


	@Test
	@Order(36)
	void Mapping_testEntityHasJoinTable() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Venue.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@JoinTable"), "Entity should contain @JoinTable annotation");
	}


	@Test
	@Order(37)
	void Mapping_testEntityHasManyToMany() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Venue.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@ManyToMany"), "Entity should contain @ManyToMany annotation");
	}


	@Test
	@Order(38)
	void Mapping_testuserHasOneToMany() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/User.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@OneToMany"), "User entity should contain @OneToMany annotation");
	}


	@Test
	@Order(39)
	void Mapping_testEventHasColumn() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Event.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@Column"), "Event entity should contain @Column annotation");
	}


	@Test
	@Order(40)
	void Mapping_testOrganizerHasOneToMany() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/entity/Organizer.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("@OneToMany"), "Organizer entity should contain @OneToMany annotation");
	}

	@Test
	@Order(41)
	public void SwaggerUI_testConfigurationFolder() {
		String directoryPath = "src/main/java/com/example/demo/config"; // Replace with the path to your directory
		File directory = new File(directoryPath);
		assertTrue(directory.exists() && directory.isDirectory());
	}

	@Test
	@Order(42)
	void SwaggerUI_testSwaggerConfigFile() {
		String filePath = "src/main/java/com/example/demo/config/SwaggerConfig.java";
		File file = new File(filePath);
		assertTrue(file.exists() && file.isFile());

	}

	@Test
	@Order(43)
	public void LOG_testLogFolderAndFileCreation() {
		String LOG_FOLDER_PATH = "logs";
		String LOG_FILE_PATH = "logs/application.log";
		File logFolder = new File(LOG_FOLDER_PATH);
		assertTrue(logFolder.exists(), "Log folder should be created");
		File logFile = new File(LOG_FILE_PATH);
		assertTrue(logFile.exists(), "Log file should be created inside 'logs' folder");
	}

	@Test
	@Order(44)
	void AOP_testAOPConfigFile() {
		String filePath = "src/main/java/com/example/demo/aspect/LoggingAspect.java";
		File file = new File(filePath);
		assertTrue(file.exists() && file.isFile());
	}

	@Test
	@Order(45)
	void AOP_testAOPConfigFileAspect() throws Exception {
		Path entityFilePath = Paths.get("src/main/java/com/example/demo/aspect/LoggingAspect.java");
		String entityFileContent = Files.readString(entityFilePath);
		assertTrue(entityFileContent.contains("Aspect"), "Book entity should contain @RequestBody annotation");
	}	
}
