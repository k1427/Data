package com.rechargebackend.pulsetopupbackend;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.lang.reflect.Method;

import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import static org.assertj.core.api.Assertions.assertThat;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.rechargebackend.pulsetopupbackend.Model.History;
import com.rechargebackend.pulsetopupbackend.Model.RechargePlan;
import com.rechargebackend.pulsetopupbackend.Model.User;
import com.rechargebackend.pulsetopupbackend.Repository.HistoryRepository;
import com.rechargebackend.pulsetopupbackend.Repository.UserRepository;
import com.rechargebackend.pulsetopupbackend.Service.HistoryService;
import com.rechargebackend.pulsetopupbackend.Service.RechargePlanService;
import com.rechargebackend.pulsetopupbackend.Service.UserService;
import com.rechargebackend.pulsetopupbackend.configuration.SwaggerConfig;



@AutoConfigureMockMvc
@TestMethodOrder(OrderAnnotation.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class CombinedControllerTest {
    private static final String LOG_FOLDER_PATH = "logs";
    private static final String LOG_FILE_PATH = "logs/application.log"; 
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private HistoryRepository historyRepository;

    @Autowired
    private UserRepository userRepository;
    
    @BeforeEach
    public void setUp() {
        historyRepository.deleteAll();
        userRepository.deleteAll();
    }
 
    @MockBean
    private UserService userService;

    @MockBean
    private HistoryService historyService;
    
    @MockBean
    private RechargePlanService rechargePlanService;

    @Autowired
    private ObjectMapper objectMapper;

    @Order(1)
    @Test
	void contextLoads() {
	}

    // Test for RechargePlan entity with Lombok annotations
    @Test
    @Order(2)
    void Annotation_testRechargeHasLombokAnnotations() throws Exception {
        // Path to the RechargePlan entity file
        Path entityFilePath = Paths.get("src/main/java/com/rechargebackend/pulsetopupbackend/Model/RechargePlan.java");

        // Read the content of the entity file as a string
        String entityFileContent = Files.readString(entityFilePath);

        // Check if annotations like @Entity and @NoArgsConstructor exist
        assertTrue(entityFileContent.contains("@Entity"), "RechargePlan entity should contain @Entity annotation");
        assertTrue(entityFileContent.contains("@NoArgsConstructor"),
                "RechargePlan entity should contain @NoArgsConstructor annotation");
    }

    // Test for User entity with Lombok annotations
    @Test
    @Order(3)
    void Annotation_testUserHasLombokAnnotations() throws Exception {
        // Path to the User entity file
        Path entityFilePath = Paths.get("src/main/java/com/rechargebackend/pulsetopupbackend/Model/User.java");

        // Read the content of the entity file as a string
        String entityFileContent = Files.readString(entityFilePath);

        // Check if the @Data annotation exists for the User entity
        assertTrue(entityFileContent.contains("@Data"), "User entity should contain @Data annotation");
    }

    // Test for User entity with @JsonIgnore annotations
    @Test
    @Order(4)
    void Annotation_testUserHasJSONIgnoreAnnotations() throws Exception {
        // Path to the User entity file
        Path entityFilePath = Paths.get("src/main/java/com/rechargebackend/pulsetopupbackend/Model/User.java");

        // Read the content of the entity file as a string
        String entityFileContent = Files.readString(entityFilePath);

        // Check if @JsonIgnore annotation exists in the User entity
        assertTrue(entityFileContent.contains("@JsonIgnore"), "User entity should contain @JsonIgnore annotation");
    }

    // Test for RechargePlan entity with @JsonProperty annotations
    @Test
    @Order(5)
    void Annotation_testUserHasJSONPropertyAnnotations() throws Exception {
        // Path to the RechargePlan entity file
        Path entityFilePath = Paths.get("src/main/java/com/rechargebackend/pulsetopupbackend/Model/RechargePlan.java");

        // Read the content of the entity file as a string
        String entityFileContent = Files.readString(entityFilePath);

        // Check if @JsonProperty annotation exists in the RechargePlan entity
        assertTrue(entityFileContent.contains("@JsonProperty"), "RechargePlan entity should contain @JsonProperty annotation");
    }

    // Test to check if UserRepository file exists in the specified path
    @Test
    @Order(6)
    public void Repository_testUserRepositoryFile() {
        // Define the path to the UserRepository file
        String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Repository/UserRepository.java";
        
        // Create a File object using the specified path
        File file = new File(filePath);
        
        // Check if the file exists and is indeed a file
        assertTrue(file.exists() && file.isFile(), "UserRepository file should exist and be a file");
    }

    // Test to check if RechargePlanRepository file exists in the specified path
    @Test
    @Order(7)
    public void Repository_testRechargePlanRepositoryFile() {
        // Define the path to the RechargePlanRepository file
        String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Repository/RechargePlanRepository.java";
        
        // Create a File object using the specified path
        File file = new File(filePath);
        
        // Check if the file exists and is indeed a file
        assertTrue(file.exists() && file.isFile(), "RechargePlanRepository file should exist and be a file");
    }

    // Test to check if HistoryRepository file exists in the specified path
    @Test
    @Order(8)
    public void Repository_testHistoryRepositoryFile() {
        // Define the path to the HistoryRepository file
        String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Repository/HistoryRepository.java";
        
        // Create a File object using the specified path
        File file = new File(filePath);
        
        // Check if the file exists and is indeed a file
        assertTrue(file.exists() && file.isFile(), "HistoryRepository file should exist and be a file");
    }

    @Test
    @Order(9)
    public void CRUD_testCreateRechargePlan() throws Exception {
        RechargePlan rechargePlan = new RechargePlan();
        rechargePlan.setId(1L);
        rechargePlan.setPlanName("Basic Plan");
        rechargePlan.setPlanDescription("A basic plan with limited features");
        rechargePlan.setPlanDuration(30);
        rechargePlan.setPrice(99.99);

        when(rechargePlanService.create(Mockito.any(RechargePlan.class))).thenReturn(rechargePlan);

        mockMvc.perform(post("/RechargePlan")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(rechargePlan)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.planName").value("Basic Plan"))
                .andExpect(jsonPath("$.price").value(99.99));

        verify(rechargePlanService, times(1)).create(Mockito.any(RechargePlan.class));
    }

    @Test
    @Order(10)
    public void CRUD_testGetAllRechargePlans() throws Exception {
        RechargePlan plan1 = new RechargePlan();
        plan1.setId(1L);
        plan1.setPlanName("Basic Plan");
        plan1.setPlanDescription("A basic plan with limited features");
        plan1.setPlanDuration(30);
        plan1.setPrice(99.99);

        RechargePlan plan2 = new RechargePlan();
        plan2.setId(2L);
        plan2.setPlanName("Premium Plan");
        plan2.setPlanDescription("A premium plan with advanced features");
        plan2.setPlanDuration(90);
        plan2.setPrice(299.99);

        List<RechargePlan> planList = Arrays.asList(plan1, plan2);

        when(rechargePlanService.findAll()).thenReturn(planList);

        mockMvc.perform(get("/RechargePlan")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[1].id").value(2));

        verify(rechargePlanService, times(1)).findAll();
    }

    @Test
    @Order(11)
    public void CRUD_testGetRechargePlanById() throws Exception {
        RechargePlan rechargePlan = new RechargePlan();
        rechargePlan.setId(1L);
        rechargePlan.setPlanName("Basic Plan");
        rechargePlan.setPlanDescription("A basic plan with limited features");
        rechargePlan.setPlanDuration(30);
        rechargePlan.setPrice(99.99);

        when(rechargePlanService.findById(1L)).thenReturn(rechargePlan);

        mockMvc.perform(get("/RechargePlan/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.planName").value("Basic Plan"));

        verify(rechargePlanService, times(1)).findById(1L);
    }

    @Test
    @Order(12)
    public void CRUD_testUpdateRechargePlan() throws Exception {
        RechargePlan updatedPlan = new RechargePlan();
        updatedPlan.setId(1L);
        updatedPlan.setPlanName("Updated Plan");
        updatedPlan.setPlanDescription("Updated description");
        updatedPlan.setPlanDuration(60);
        updatedPlan.setPrice(199.99);

        when(rechargePlanService.update(eq(1L), Mockito.any(RechargePlan.class))).thenReturn(updatedPlan);

        mockMvc.perform(put("/RechargePlan/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updatedPlan)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.planName").value("Updated Plan"))
                .andExpect(jsonPath("$.price").value(199.99));

        verify(rechargePlanService, times(1)).update(eq(1L), Mockito.any(RechargePlan.class));
    }

    @Test
    @Order(13)
    public void CRUD_testDeleteRechargePlan() throws Exception {
        doNothing().when(rechargePlanService).delete(1L);

        mockMvc.perform(delete("/RechargePlan/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        verify(rechargePlanService, times(1)).delete(1L);
    }

    @Test
    @Order(14)
    public void CRUD_testCreateHistory() throws Exception {
        History history = new History();
        history.setId(1L);
        history.setUserId(1);
        history.setRechargePlan("Plan A");
        history.setDate(LocalDate.now());
        history.setTime("10:00 AM");

        when(historyService.create(Mockito.any(History.class))).thenReturn(history);

        mockMvc.perform(post("/History")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(history)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.userId").value(1))
                .andExpect(jsonPath("$.rechargePlan").value("Plan A"));

        verify(historyService, times(1)).create(Mockito.any(History.class));
    }

    @Test
    @Order(15)
    public void CRUD_testGetAllHistories() throws Exception {
        History history1 = new History();
        history1.setId(1L);
        history1.setUserId(1);
        history1.setRechargePlan("Plan A");
        history1.setDate(LocalDate.now());
        history1.setTime("10:00 AM");

        History history2 = new History();
        history2.setId(2L);
        history2.setUserId(2);
        history2.setRechargePlan("Plan B");
        history2.setDate(LocalDate.now());
        history2.setTime("11:00 AM");

        List<History> historyList = Arrays.asList(history1, history2);

        when(historyService.findAll()).thenReturn(historyList);

        mockMvc.perform(get("/History")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[1].id").value(2));

        verify(historyService, times(1)).findAll();
    }

    @Test
    @Order(16)
    public void CRUD_testGetHistoryById() throws Exception {
        History history = new History();
        history.setId(1L);
        history.setUserId(1);
        history.setRechargePlan("Plan A");
        history.setDate(LocalDate.now());
        history.setTime("10:00 AM");

        when(historyService.findById(1L)).thenReturn(history);

        mockMvc.perform(get("/History/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.rechargePlan").value("Plan A"));

        verify(historyService, times(1)).findById(1L);
    }

    @Test
    @Order(17)
    public void CRUD_testUpdateHistory() throws Exception {
        History updatedHistory = new History();
        updatedHistory.setId(1L);
        updatedHistory.setUserId(1);
        updatedHistory.setRechargePlan("Updated Plan");
        updatedHistory.setDate(LocalDate.now());
        updatedHistory.setTime("12:00 PM");

        when(historyService.update(eq(1L), Mockito.any(History.class))).thenReturn(updatedHistory);

        mockMvc.perform(put("/History/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updatedHistory)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.rechargePlan").value("Updated Plan"));

        verify(historyService, times(1)).update(eq(1L), Mockito.any(History.class));
    }

    @Test
    @Order(18)
    public void CRUD_testDeleteHistory() throws Exception {
        doNothing().when(historyService).delete(1L);

        mockMvc.perform(delete("/History/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        verify(historyService, times(1)).delete(1L);
    }

    @Test
    @Order(19)
    void CRUD_testCreateUser() throws Exception {
        User user = new User();
        user.setId(1L);
        user.setUsername("John Doe");
        user.setEmail("john.doe@example.com");

        when(userService.createUser(any(User.class))).thenReturn(user);

        mockMvc.perform(post("/api/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\": \"John Doe\", \"email\": \"john.doe@example.com\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("John Doe"))
                .andExpect(jsonPath("$.email").value("john.doe@example.com"));
    }

    @Test
    @Order(20)
    void CRUD_testGetUserById() throws Exception {
        User user = new User();
        user.setId(1L);
        user.setUsername("John Doe");
        user.setEmail("john.doe@example.com");

        when(userService.getUserById(anyLong())).thenReturn(Optional.of(user));

        mockMvc.perform(get("/api/users/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("John Doe"))
                .andExpect(jsonPath("$.email").value("john.doe@example.com"));
    }

    @Test
    @Order(21)
    void CRUD_testGetUserByIdNotFound() throws Exception {
        when(userService.getUserById(anyLong())).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/users/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    @Order(22)
    void CRUD_testGetAllUsers() throws Exception {
        User user1 = new User();
        user1.setId(1L);
        user1.setUsername("John Doe");
        user1.setEmail("john.doe@example.com");

        User user2 = new User();
        user2.setId(2L);
        user2.setUsername("Jane Doe");
        user2.setEmail("jane.doe@example.com");

        when(userService.getAllUsers()).thenReturn(Arrays.asList(user1, user2));

        mockMvc.perform(get("/api/users")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[1].id").value(2));
    }

    @Test
    @Order(23)
    void CRUD_testUpdateUser() throws Exception {
        User user = new User();
        user.setId(1L);
        user.setUsername("John Doe");
        user.setEmail("john.doe@example.com");

        User updatedUser = new User();
        updatedUser.setId(1L);
        updatedUser.setUsername("John Smith");
        updatedUser.setEmail("john.smith@example.com");

        when(userService.updateUser(anyLong(), any(User.class))).thenReturn(Optional.of(updatedUser));

        mockMvc.perform(put("/api/users/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\": \"John Smith\", \"email\": \"john.smith@example.com\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.username").value("John Smith"))
                .andExpect(jsonPath("$.email").value("john.smith@example.com"));

    }

    @Test
    @Order(24)
    void CRUD_testDeleteUser() throws Exception {
        when(userService.deleteUser(anyLong())).thenReturn(true);

        mockMvc.perform(delete("/api/users/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }

    @Test
    @Order(25)
    void CRUD_testPathVariableAnnotations() throws Exception {
        // Path to the UserController entity file
        Path entityFilePath = Paths.get("src/main/java/com/rechargebackend/pulsetopupbackend/Controller/UserController.java");

        // Read the content of the entity file as a string
        String entityFileContent = Files.readString(entityFilePath);

        // Check if @PathVariable annotation exists in the UserController
        assertTrue(entityFileContent.contains("@PathVariable"), "UserController should contain @PathVariable annotation");
    }

    @Test
    @Order(26)
    void CRUD_testRequestBodyAnnotations() throws Exception {
        // Path to the HistoryController entity file
        Path entityFilePath = Paths.get("src/main/java/com/rechargebackend/pulsetopupbackend/Controller/HistoryController.java");

        // Read the content of the entity file as a string
        String entityFileContent = Files.readString(entityFilePath);

        // Check if @RequestBody annotation exists in the HistoryController
        assertTrue(entityFileContent.contains("@RequestBody"), "HistoryController should contain @RequestBody annotation");
    }

    @Test
    @Order(27)
    public void JPQL_testFindHistoriesByUserAndDateRange() {
        // Arrange
        User user = new User();
        user.setUsername("john_doe");
        user.setPassword("password");
        user.setEmail("john.doe@example.com");
        user = userRepository.save(user);

        History history1 = new History();
        history1.setUser(user);
        history1.setRechargePlan("Plan A");
        history1.setDate(LocalDate.of(2025, 1, 1));
        history1.setTime("10:00 AM");
        historyRepository.save(history1);

        History history2 = new History();
        history2.setUser(user);
        history2.setRechargePlan("Plan B");
        history2.setDate(LocalDate.of(2025, 1, 5));
        history2.setTime("2:00 PM");
        historyRepository.save(history2);

        History history3 = new History();
        history3.setUser(user);
        history3.setRechargePlan("Plan C");
        history3.setDate(LocalDate.of(2025, 2, 1));
        history3.setTime("4:00 PM");
        historyRepository.save(history3);

        // Act
        List<History> result = historyRepository.findHistoriesByUserAndDateRange(
            user.getId(), LocalDate.of(2025, 1, 1), LocalDate.of(2025, 1, 31));

        // Assert
        assertThat(result).isNotEmpty();
        assertThat(result).hasSize(2);
        assertThat(result).extracting("rechargePlan").containsExactlyInAnyOrder("Plan A", "Plan B");
    }

    @Test
    @Order(28)
    public void JPQL_testFindHistoriesByUserAndDateRange_NoHistories() {
        // Arrange
        User user = new User();
        user.setUsername("jane_doe");
        user.setPassword("password");
        user.setEmail("jane.doe@example.com");
        user = userRepository.save(user);

        History history = new History();
        history.setUser(user);
        history.setRechargePlan("Plan X");
        history.setDate(LocalDate.of(2025, 3, 1));
        history.setTime("9:00 AM");
        historyRepository.save(history);

        // Act
        List<History> result = historyRepository.findHistoriesByUserAndDateRange(
            user.getId(), LocalDate.of(2025, 1, 1), LocalDate.of(2025, 1, 31));

        // Assert
        assertThat(result).isEmpty();
    }

    @Test
    @Order(29)
    public void JPQL_testFindHistoriesByUserAndDateRange_MultipleUsers() {
        // Arrange
        User user1 = new User();
        user1.setUsername("alice");
        user1.setPassword("password");
        user1.setEmail("alice@example.com");
        user1 = userRepository.save(user1);

        User user2 = new User();
        user2.setUsername("bob");
        user2.setPassword("password");
        user2.setEmail("bob@example.com");
        user2 = userRepository.save(user2);

        History history1 = new History();
        history1.setUser(user1);
        history1.setRechargePlan("Plan 1");
        history1.setDate(LocalDate.of(2025, 1, 10));
        history1.setTime("11:00 AM");
        historyRepository.save(history1);

        History history2 = new History();
        history2.setUser(user2);
        history2.setRechargePlan("Plan 2");
        history2.setDate(LocalDate.of(2025, 1, 15));
        history2.setTime("3:00 PM");
        historyRepository.save(history2);

        // Act
        List<History> result = historyRepository.findHistoriesByUserAndDateRange(
            user1.getId(), LocalDate.of(2025, 1, 1), LocalDate.of(2025, 1, 31));

        // Assert
        assertThat(result).isNotEmpty();
        assertThat(result).hasSize(1);
        assertThat(result).extracting("rechargePlan").containsExactly("Plan 1");
    }

    @Test
    @Order(30)
    public void JPQL_testFindHistoriesByUserAndDateRange_EdgeDates() {
        // Arrange
        User user = new User();
        user.setUsername("charlie");
        user.setPassword("password");
        user.setEmail("charlie@example.com");
        user = userRepository.save(user);

        History history1 = new History();
        history1.setUser(user);
        history1.setRechargePlan("Plan Start");
        history1.setDate(LocalDate.of(2025, 1, 1));
        history1.setTime("8:00 AM");
        historyRepository.save(history1);

        History history2 = new History();
        history2.setUser(user);
        history2.setRechargePlan("Plan End");
        history2.setDate(LocalDate.of(2025, 1, 31));
        history2.setTime("6:00 PM");
        historyRepository.save(history2);

        // Act
        List<History> result = historyRepository.findHistoriesByUserAndDateRange(
            user.getId(), LocalDate.of(2025, 1, 1), LocalDate.of(2025, 1, 31));

        // Assert
        assertThat(result).isNotEmpty();
        assertThat(result).hasSize(2);
        assertThat(result).extracting("rechargePlan").containsExactlyInAnyOrder("Plan Start", "Plan End");
    }

    @Test
    @Order(31)
    public void JPQL_testFindHistoriesByUserAndDateRange_OverlappingRange() {
        // Arrange
        User user = new User();
        user.setUsername("dave");
        user.setPassword("password");
        user.setEmail("dave@example.com");
        user = userRepository.save(user);

        History history1 = new History();
        history1.setUser(user);
        history1.setRechargePlan("Plan Overlap 1");
        history1.setDate(LocalDate.of(2025, 1, 5));
        history1.setTime("7:00 PM");
        historyRepository.save(history1);

        History history2 = new History();
        history2.setUser(user);
        history2.setRechargePlan("Plan Overlap 2");
        history2.setDate(LocalDate.of(2025, 1, 20));
        history2.setTime("9:00 AM");
        historyRepository.save(history2);

        // Act
        List<History> result = historyRepository.findHistoriesByUserAndDateRange(
            user.getId(), LocalDate.of(2025, 1, 10), LocalDate.of(2025, 1, 25));

        // Assert
        assertThat(result).isNotEmpty();
        assertThat(result).hasSize(1);
        assertThat(result).extracting("rechargePlan").containsExactly("Plan Overlap 2");
    }

    @Test
    @Order(32)
    void PaginateSorting_testPaginateAndSortUserController() throws Exception {
    // Path to the UserController file
    Path entityFilePath = Paths.get("src/main/java/com/rechargebackend/pulsetopupbackend/Controller/UserController.java");

    // Read the content of the entity file as a string
    String entityFileContent = Files.readString(entityFilePath);

    // Check if pagination and sorting endpoint exists
    assertTrue(entityFileContent.contains("public ResponseEntity<Page<User>> getAllUsersPaginateAndSort"),
            "UserController should contain /paginate endpoint for pagination and sorting");
    }

    @Test
    @Order(33)
    void PaginateSorting_testPaginateAndSortUserService() throws Exception {
        // Path to the UserService file
        Path entityFilePath = Paths.get("src/main/java/com/rechargebackend/pulsetopupbackend/Service/UserService.java");

        // Read the content of the entity file as a string
        String entityFileContent = Files.readString(entityFilePath);

        // Check if pagination and sorting method exists in the service
        assertTrue(entityFileContent.contains("public Page<User> getAllUsersPaginateAndSort"),
                "UserService should contain getAllUsersPaginateAndSort method for pagination and sorting");
    }

    @Test
    @Order(34)
    void PageAndJPQL_testPagination_User() {
        // Simulate a GET request to fetch users with pagination
        ResponseEntity<String> response = restTemplate.getForEntity("/api/users?page=0&size=10", String.class);

        // Assert that the response status is OK
        assertEquals(HttpStatus.OK, response.getStatusCode(), "Response status should be OK");

        // Assert that the response body is not empty (assuming it's a JSON array of users)
        assertNotNull(response.getBody(), "Response body should not be null");
    }

    @Test
    @Order(35)
    void PageAndJPQL_testPagination_RechargePlan() {
        // Simulate a GET request to fetch users with pagination
        ResponseEntity<String> response = restTemplate.getForEntity("/RechargePlan?page=0&size=10", String.class);

        // Assert that the response status is OK
        assertEquals(HttpStatus.OK, response.getStatusCode(), "Response status should be OK");

        // Assert that the response body is not empty (assuming it's a JSON array of users)
        assertNotNull(response.getBody(), "Response body should not be null");
    }

    @Test
    @Order(36)
    void Mapping_testUserEntityHasJoinTable() throws Exception {
        // Path to the User entity file
        Path entityFilePath = Paths.get("src/main/java/com/rechargebackend/pulsetopupbackend/Model/User.java");

        // Read the content of the entity file as a string
        String entityFileContent = Files.readString(entityFilePath);

        // Check if the @JoinTable annotation exists in the User entity file
        assertTrue(entityFileContent.contains("@JoinTable"), "User entity should contain @JoinTable annotation for mapping relationships");
    }

    @Test
    @Order(37)
    void Mapping_testRechargeHasManyToMany() throws Exception {
        // Path to the RechargePlan entity file
        Path entityFilePath = Paths.get("src/main/java/com/rechargebackend/pulsetopupbackend/Model/RechargePlan.java");

        // Read the content of the entity file as a string
        String entityFileContent = Files.readString(entityFilePath);

        // Check if the @ManyToMany annotation exists in the RechargePlan entity file
        assertTrue(entityFileContent.contains("@ManyToMany"), "RechargePlan entity should contain @ManyToMany annotation for relationships");
    }

    @Test
    @Order(38)
    void Mapping_testHistoryHasManyToOne() throws Exception {
        // Path to the History entity file
        Path entityFilePath = Paths.get("src/main/java/com/rechargebackend/pulsetopupbackend/Model/History.java");

        // Read the content of the entity file as a string
        String entityFileContent = Files.readString(entityFilePath);

        // Check if the @ManyToOne annotation exists in the History entity file
        assertTrue(entityFileContent.contains("@ManyToOne"), "History entity should contain @ManyToOne annotation for relationships");
    }

    @Test
    @Order(39)
    void Mapping_testHistoryHasColumn() throws Exception {
        // Path to the History entity file
        Path entityFilePath = Paths.get("src/main/java/com/rechargebackend/pulsetopupbackend/Model/History.java");

        // Read the content of the entity file as a string
        String entityFileContent = Files.readString(entityFilePath);

        // Check if the @Column annotation exists in the History entity file
        assertTrue(entityFileContent.contains("@Column"), "History entity should contain @Column annotation for field mapping");
    }

    @Test
    @Order(40)
    void Mapping_testUserHasOneToMany() throws Exception {
        // Path to the User entity file
        Path entityFilePath = Paths.get("src/main/java/com/rechargebackend/pulsetopupbackend/Model/User.java");

        // Read the content of the entity file as a string
        String entityFileContent = Files.readString(entityFilePath);

        // Check if the @OneToMany annotation exists in the User entity file
        assertTrue(entityFileContent.contains("@OneToMany"), "User entity should contain @OneToMany annotation for relationships");
    }

    @Test
    @Order(41)
    public void SwaggerUI_testConfigurationFolder() { 
        String directoryPath = "src/main/java/com/rechargebackend/pulsetopupbackend/configuration"; // Replace with the path to your directory 
        File directory = new File(directoryPath); 
        assertTrue(directory.exists() && directory.isDirectory(), "The specified configuration folder should exist and be a directory.");
    }

    @Test
    @Order(42)
    public void SwaggerUI_testCustomOpenAPIBeanCreation() {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SwaggerConfig.class);
        OpenAPI openAPI = context.getBean(OpenAPI.class);

        assertNotNull(openAPI, "OpenAPI bean should not be null.");
        Info info = openAPI.getInfo();
        assertNotNull(info, "OpenAPI Info should not be null.");
        assertEquals("My API", info.getTitle(), "API title should match the expected value.");
        assertEquals("1.0", info.getVersion(), "API version should match the expected value.");
        assertEquals("API documentation using Swagger", info.getDescription(), "API description should match the expected value.");
        context.close();
    }

    @Test
    @Order(43)
    public void SwaggerUI_testCustomOpenAPIMethodIsAnnotatedWithBean() throws NoSuchMethodException {
        Method method = SwaggerConfig.class.getDeclaredMethod("customOpenAPI");
        Bean beanAnnotation = method.getAnnotation(Bean.class);
        assertTrue(beanAnnotation != null, "customOpenAPI method should be annotated with @Bean.");
    }

    @Test
    @Order(44)
    public void SwaggerUI_testConfigurationAnnotation() {
        Configuration configurationAnnotation = SwaggerConfig.class.getAnnotation(Configuration.class);
        assertTrue(configurationAnnotation != null, "SwaggerConfig should be annotated with @Configuration.");
    }

    @Test
    @Order(45)
    void SwaggerUI_testSwaggerUIEndpointIsAccessible() {
        // Make a GET request to the Swagger UI URL
        ResponseEntity<String> response = restTemplate.getForEntity("/swagger-ui/index.html", String.class);

        // Assert that the endpoint returns a 200 OK status
        assertEquals(HttpStatus.OK, response.getStatusCode(), "Swagger UI endpoint is not accessible");
    }  

    @Test
    @Order(46)
    public void Log_testLogFolderAndFileCreation() {
        // Check if the "logs" folder exists
        File logFolder = new File(LOG_FOLDER_PATH);
        assertTrue(logFolder.exists(), "Log folder should be created");

        // Check if the "application.log" file exists inside the "logs" folder
        File logFile = new File(LOG_FILE_PATH);
        assertTrue(logFile.exists(), "Log file should be created inside 'logs' folder");
    }

    @Test
    @Order(47)
    void Log_testAopFunctionality() {
        // Trigger AOP by making a GET request to UserController
        ResponseEntity<String> response = restTemplate.getForEntity("/api/users", String.class);

        // Assert that the response is valid (indicating the controller method was executed)
        assertNotNull(response.getBody());

        // You can check the console log for the "AOP: Method called" message
    }

    @Test
    @Order(48)
    void AOP_testAOPConfigFile() {
        // Path to the LoggingAspect class file
        String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/aspect/LoggingAspect.java";
    
        // Create a File object
        File file = new File(filePath);
    
        // Assert that the file exists and is a valid file
        assertTrue(file.exists() && file.isFile(), "LoggingAspect.java file should exist at the specified path.");
    }
    
    @Test
    @Order(49)
    void AOP_testAOPConfigFileAspect() throws Exception {
        // Path to the LoggingAspect class file
        Path aspectFilePath = Paths.get("src/main/java/com/rechargebackend/pulsetopupbackend/aspect/LoggingAspect.java");
    
        // Read the content of the aspect file
        String aspectFileContent = Files.readString(aspectFilePath);
    
        // Check if the file contains @Aspect annotation to ensure it's an Aspect class
        assertTrue(aspectFileContent.contains("@Aspect"), "The LoggingAspect.java should be annotated with @Aspect.");
    
        // Check if the file contains the logger definition to ensure logging functionality is implemented
        assertTrue(aspectFileContent.contains("private static final Logger logger"), "The LoggingAspect.java should define a logger for logging.");
    }
    
    @Test
    @Order(50)
    void AOP_testAspectMethods() throws Exception {
        // Path to the LoggingAspect class file
        Path aspectFilePath = Paths.get("src/main/java/com/rechargebackend/pulsetopupbackend/aspect/LoggingAspect.java");
    
        // Read the content of the aspect file
        String aspectFileContent = Files.readString(aspectFilePath);
    
        // Check for @Before and @AfterReturning annotations to ensure aspect methods are properly defined
        assertTrue(aspectFileContent.contains("@Before"), "@Before annotation should be present in the LoggingAspect.java");
        assertTrue(aspectFileContent.contains("@AfterReturning"), "@AfterReturning annotation should be present in the LoggingAspect.java");
    }
    
    @Test
    @Order(51)
    void AOP_testLoggingStatements() throws Exception {
        // Path to the LoggingAspect class file
        Path aspectFilePath = Paths.get("src/main/java/com/rechargebackend/pulsetopupbackend/aspect/LoggingAspect.java");
    
        // Read the content of the aspect file
        String aspectFileContent = Files.readString(aspectFilePath);
    
        // Check if logging statements are present in the aspect methods
        assertTrue(aspectFileContent.contains("logger.info"), "The LoggingAspect.java should contain logger.info statements for logging.");
    } 
}


