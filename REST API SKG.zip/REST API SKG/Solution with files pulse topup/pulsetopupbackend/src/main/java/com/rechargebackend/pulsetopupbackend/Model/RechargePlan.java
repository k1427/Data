package com.rechargebackend.pulsetopupbackend.Model;

public class RechargePlan {
    //@ManyToMany
}
