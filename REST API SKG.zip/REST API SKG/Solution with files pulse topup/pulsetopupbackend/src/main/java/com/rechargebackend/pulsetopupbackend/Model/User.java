package com.rechargebackend.pulsetopupbackend.Model;

public class User {
    //@OneToMany
}
