package com.rechargebackend.pulsetopupbackend.Repository;

public class GrievanceEmployeeRepository {
    
}
