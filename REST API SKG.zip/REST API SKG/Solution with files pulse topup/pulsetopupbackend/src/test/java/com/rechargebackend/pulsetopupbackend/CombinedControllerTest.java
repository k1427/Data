package com.rechargebackend.pulsetopupbackend;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(OrderAnnotation.class)
class CombinedControllerTest {

    @Autowired
    private MockMvc mockMvc;

//     @Order(1)
//     @Test
//     void test_Create_ContactSupport() throws Exception {
//         // Update the JSON payload to reflect the integer value for submittedBy
//         String contactSupportJson = "{\"message\": \"Test message\", \"submittedBy\": 1}";

//         mockMvc.perform(MockMvcRequestBuilders.post("/api/contact-support")
//                 .contentType(MediaType.APPLICATION_JSON)
//                 .content(contactSupportJson)
//                 .accept(MediaType.APPLICATION_JSON))
//                 .andExpect(status().isCreated())
//                 .andExpect(jsonPath("$.message").value("Test message"))
//                 .andExpect(jsonPath("$.submittedBy").value(1)) // Expecting integer 1 instead of "User1"
//                 .andDo(print())
//                 .andReturn();
//     }


//     @Order(2)
//     @Test
//     void test_Get_All_ContactSupportEntries() throws Exception {
//         mockMvc.perform(MockMvcRequestBuilders.get("/api/contact-support")
//                 .accept(MediaType.APPLICATION_JSON))
//                 .andDo(print())
//                 .andExpect(status().isOk())
//                 .andExpect(jsonPath("$").isArray())
//                 .andReturn();
//     }

//     @Order(3)
//     @Test
//     void test_Create_Grievance() throws Exception {
//         // Update the JSON payload to reflect the integer value for submittedBy
//         String grievanceJson = "{\"subject\": \"Subject1\", \"description\": \"Description1\", \"submittedOn\": \"2024-09-09\", \"submittedBy\": 1}";

//         mockMvc.perform(MockMvcRequestBuilders.post("/api/grievances")
//                 .contentType(MediaType.APPLICATION_JSON)
//                 .content(grievanceJson)
//                 .accept(MediaType.APPLICATION_JSON))
//                 .andExpect(status().isCreated())
//                 .andExpect(jsonPath("$.subject").value("Subject1"))
//                 .andExpect(jsonPath("$.description").value("Description1"))
//                 .andExpect(jsonPath("$.submittedOn").value("2024-09-09"))
//                 .andExpect(jsonPath("$.submittedBy").value(1)) // Expecting integer 1 instead of "User1"
//                 .andDo(print())
//                 .andReturn();
// }


//     @Order(4)
//     @Test
//     void test_Get_All_Grievances() throws Exception {
//         mockMvc.perform(MockMvcRequestBuilders.get("/api/grievances")
//                 .accept(MediaType.APPLICATION_JSON))
//                 .andDo(print())
//                 .andExpect(status().isOk())
//                 .andExpect(jsonPath("$").isArray())
//                 .andReturn();
//     }

//     @Order(5)
//     @Test
//     void test_Create_Grievance_Employee() throws Exception {
//         String grievanceEmployeeJson = "{\"employeeName\": \"Employee1\", \"employeeAddress\": \"Address1\", \"employeePhone\": \"1234567890\"}";
//         mockMvc.perform(MockMvcRequestBuilders.post("/api/grievance-employees")
//                 .contentType(MediaType.APPLICATION_JSON)
//                 .content(grievanceEmployeeJson)
//                 .accept(MediaType.APPLICATION_JSON))
//                 .andExpect(MockMvcResultMatchers.status().isCreated())
//                 .andReturn();
//     }

//     @Order(6)
//     @Test
//     void test_Get_All_GrievanceEmployees() throws Exception {
//         mockMvc.perform(MockMvcRequestBuilders.get("/api/grievance-employees")
//                 .accept(MediaType.APPLICATION_JSON))
//                 .andDo(print())
//                 .andExpect(status().isOk())
//                 .andExpect(jsonPath("$").isArray())
//                 .andReturn();
//     }

//     @Order(7)
//     @Test
//     void test_Create_History() throws Exception {
//         String historyJson = "{\"userId\": 1, \"rechargePlan\": \"Plan1\", \"date\": \"" + LocalDateTime.now().toLocalDate() + "\", \"time\": \"" + LocalDateTime.now().toLocalTime() + "\"}";
//         mockMvc.perform(MockMvcRequestBuilders.post("/postHistory")
//                 .contentType(MediaType.APPLICATION_JSON)
//                 .content(historyJson)
//                 .accept(MediaType.APPLICATION_JSON))
//                 .andExpect(MockMvcResultMatchers.status().isOk())
//                 .andReturn();
//     }

//     @Order(8)
//     @Test
//     void test_Get_All_History() throws Exception {
//         mockMvc.perform(MockMvcRequestBuilders.get("/getHistory")
//                 .accept(MediaType.APPLICATION_JSON))
//                 .andDo(print())
//                 .andExpect(status().isOk())
//                 .andExpect(jsonPath("$").isArray())
//                 .andReturn();
//     }

//     @Order(9)
//     @Test
//     void test_Create_RechargePlan() throws Exception {
//         String rechargePlanJson = "{\"planName\": \"Plan1\", \"planDescription\": \"Description1\", \"planDuration\": 30, \"price\": 100.0}";
//         mockMvc.perform(MockMvcRequestBuilders.post("/api/rechargeplans")
//                 .contentType(MediaType.APPLICATION_JSON)
//                 .content(rechargePlanJson)
//                 .accept(MediaType.APPLICATION_JSON))
//                 .andExpect(MockMvcResultMatchers.status().isCreated())
//                 .andReturn();
//     }

//     @Order(10)
//     @Test
//     void test_Get_All_RechargePlans() throws Exception {
//         mockMvc.perform(MockMvcRequestBuilders.get("/api/rechargeplans")
//                 .accept(MediaType.APPLICATION_JSON))
//                 .andDo(print())
//                 .andExpect(status().isOk())
//                 .andExpect(jsonPath("$").isArray())
//                 .andReturn();
//     }

//     @Order(11)
//     @Test
//     void test_CreateUser() throws Exception {
//         String userJson = "{\"email\": \"user@example.com\", \"password\": \"password123\"}";
//         mockMvc.perform(MockMvcRequestBuilders.post("/register")
//                 .contentType(MediaType.APPLICATION_JSON)
//                 .content(userJson)
//                 .accept(MediaType.APPLICATION_JSON))
//                 .andExpect(MockMvcResultMatchers.status().isOk())
//                 .andReturn();
//     }

   
     
     @Test
     @Order(13)
     public void test_Controller_GrievanceController_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Controller/GrievanceController.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(14)
     public void test_Controller_HistoryController_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Controller/HistoryController.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(15)
     public void test_Controller_GrievanceEmployeeController_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Controller/GrievanceEmployeeController.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(16)
     public void test_Controller_RechargePlanController_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Controller/RechargePlanController.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(17)
     public void test_Controller_UserController_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Controller/UserController.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(18)
     public void test_Model_ContactSupport_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Model/ContactSupport.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(19)
     public void test_Model_User_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Model/User.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(20)
     public void test_Model_RechargePlan_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Model/RechargePlan.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(21)
     public void test_Model_History_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Model/History.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(22)
     public void test_Model_GrievanceEmployee_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Model/GrievanceEmployee.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(23)
     public void test_Model_Grievance_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Model/Grievance.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(24)
     public void test_Repository_ContactSupport_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Repository/ContactSupportRepository.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(25)
     public void test_Repository_User_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Repository/UserRepository.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(26)
     public void test_Repository_RechargePlan_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Repository/RechargePlanRepository.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(27)
     public void test_Repository_History_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Repository/HistoryRepository.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(29)
     public void test_Repository_GrievanceEmployee_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Repository/GrievanceEmployeeRepository.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(30)
     public void test_Repository_Grievance_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Repository/GrievanceRepository.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(31)
     public void test_Service_ContactSupport_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Service/ContactSupportService.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(32)
     public void test_Service_User_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Service/UserService.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(33)
     public void test_Service_RechargePlan_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Service/RechargePlanService.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(34)
     public void test_Service_History_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Service/HistoryService.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(35)
     public void test_Service_GrievanceEmployee_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Service/GrievanceEmployeeService.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(36)
     public void test_Service_Grievance_File() {
           String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Service/GrievanceService.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     
     @Test
     @Order(37)
    public void test_OneToMany_Annotation() throws IOException {
        // Path to the file to be tested
        String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Model/User.java";
        String searchString = "@OneToMany";
 
        boolean containsString = false;
 
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(searchString)) {
                    containsString = true;
                    break;
                }
            }
        }
 
        // Assert that the string is present in the file
        assertTrue(containsString, "The file does not contain the string '@OneToMany'");
    }
     @Test
     @Order(38)
    public void test_OneToOne_Annotation() throws IOException {
        // Path to the file to be tested
        String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Model/ContactSupport.java";
        String searchString = "@OneToOne";
 
        boolean containsString = false;
 
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(searchString)) {
                    containsString = true;
                    break;
                }
            }
        }
 
        // Assert that the string is present in the file
        assertTrue(containsString, "The file does not contain the string '@OneToOne'");
    }
     @Test
     @Order(39)
    public void test_ManyToMany_Annotation() throws IOException {
        // Path to the file to be tested
        String filePath = "src/main/java/com/rechargebackend/pulsetopupbackend/Model/RechargePlan.java";
        String searchString = "@ManyToMany";
 
        boolean containsString = false;
 
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(searchString)) {
                    containsString = true;
                    break;
                }
            }
        }
 
        // Assert that the string is present in the file
        assertTrue(containsString, "The file does not contain the string 'ManyToMany'");
    }
    
}
