import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { BrowserRouter as Router } from 'react-router-dom';
import Registration from '../components/Registration';
import Personalization from '../components/Personalization';
import OrderPlacement from '../components/OrderPlacement';
import Payment from '../components/Payment';

// Mock console.log to avoid unnecessary log output during tests
beforeAll(() => {
  jest.spyOn(console, 'log').mockImplementation(() => {});
});

describe('Online Customized Gift Portal', () => {

  // Registration Tests
  test('renders registration form and handles input and submission', () => {
    render(
      <Router>
        <Registration />
      </Router>
    );

    const nameInput = screen.getByPlaceholderText(/Name/i);
    const emailInput = screen.getByPlaceholderText(/Email/i);
    const passwordInput = screen.getByPlaceholderText(/Password/i);
    const submitButton = screen.getByText(/Register/i);

    fireEvent.change(nameInput, { target: { value: 'John Doe' } });
    fireEvent.change(emailInput, { target: { value: 'johndoe@example.com' } });
    fireEvent.change(passwordInput, { target: { value: 'password123' } });
    fireEvent.click(submitButton);

    expect(nameInput.value).toBe('John Doe');
    expect(emailInput.value).toBe('johndoe@example.com');
    expect(passwordInput.value).toBe('password123');
  });


  // Personalization Tests
  test('shows correct message preview', () => {
    render(<Personalization />);

    // Get the message input field and the message preview
    const messageInput = screen.getByPlaceholderText(/Message/i);
    const messagePreview = screen.getByText(/Message:/i);

    // Simulate user input for the message
    fireEvent.change(messageInput, { target: { value: 'Happy Birthday!' } });

    // Assert that the preview text updates correctly
    expect(messagePreview.textContent).toBe('Message: Happy Birthday!');
});

 
  // Order Placement Tests
  test('renders order placement form and handles input', () => {
    render(
      <Router>
        <OrderPlacement />
      </Router>
    );

    const addressInput = screen.getByPlaceholderText(/Shipping Address/i);
    const phoneInput = screen.getByPlaceholderText(/Phone Number/i);
    const orderButton = screen.getByText(/Place Order/i);

    fireEvent.change(addressInput, { target: { value: '123 Main St' } });
    fireEvent.change(phoneInput, { target: { value: '1234567890' } });
    fireEvent.click(orderButton);

    expect(addressInput.value).toBe('123 Main St');
    expect(phoneInput.value).toBe('1234567890');
  });

  test('updates order details when inputs are changed', () => {
    render(<OrderPlacement />);
  
    const addressInput = screen.getByPlaceholderText(/Shipping Address/i);
    const phoneInput = screen.getByPlaceholderText(/Phone Number/i);
  
    // Simulate typing into the address and phone input fields
    fireEvent.change(addressInput, { target: { value: '123 Main St' } });
    fireEvent.change(phoneInput, { target: { value: '123-456-7890' } });
  
    // Check if the state updates correctly (you can spy on console.log or check inputs)
    expect(addressInput.value).toBe('123 Main St');
    expect(phoneInput.value).toBe('123-456-7890');
  });
  test('calls handleOrder when Place Order button is clicked', () => {
    render(<OrderPlacement />);
  
    const logSpy = jest.spyOn(console, 'log').mockImplementation();
  
    const addressInput = screen.getByPlaceholderText(/Shipping Address/i);
    const phoneInput = screen.getByPlaceholderText(/Phone Number/i);
    const placeOrderButton = screen.getByText(/Place Order/i);
  
    // Fill in the input fields
    fireEvent.change(addressInput, { target: { value: '123 Main St' } });
    fireEvent.change(phoneInput, { target: { value: '123-456-7890' } });
  
    // Simulate clicking the Place Order button
    fireEvent.click(placeOrderButton);
  
    // Check if handleOrder logs the order details
    expect(logSpy).toHaveBeenCalledWith('Order Placed:', { address: '123 Main St', phone: '123-456-7890' });
  
    // Clean up the spy
    logSpy.mockRestore();
  });
  
  test('input fields should be empty initially', () => {
    render(<OrderPlacement />);
  
    const addressInput = screen.getByPlaceholderText(/Shipping Address/i);
    const phoneInput = screen.getByPlaceholderText(/Phone Number/i);
  
    // Check if the input fields are initially empty
    expect(addressInput.value).toBe('');
    expect(phoneInput.value).toBe('');
  });
  
  // Payment Tests
  test('renders payment button and handles click', () => {
    render(
      <Router>
        <Payment />
      </Router>
    );

    const paymentButton = screen.getByText(/Proceed with Payment/i);
    fireEvent.click(paymentButton);

    // Ensure that the button's text is displayed
    expect(screen.getByText(/Proceed with Payment/i)).toBeInTheDocument();
  });
  test('renders registration form and handles input', () => {
    render(<Registration />);
    const nameInput = screen.getByPlaceholderText(/Name/i);
    const emailInput = screen.getByPlaceholderText(/Email/i);
    const passwordInput = screen.getByPlaceholderText(/Password/i);

    fireEvent.change(nameInput, { target: { value: 'John Doe' } });
    fireEvent.change(emailInput, { target: { value: 'john.doe@example.com' } });
    fireEvent.change(passwordInput, { target: { value: 'password123' } });

    expect(nameInput.value).toBe('John Doe');
    expect(emailInput.value).toBe('john.doe@example.com');
    expect(passwordInput.value).toBe('password123');
});

test('payment button should be enabled initially', () => {
    render(<Payment />);
    
    const paymentButton = screen.getByText(/Proceed with Payment/i);
    
    // Assert that the payment button is not disabled initially
    expect(paymentButton).not.toBeDisabled();
  });
  
  
test('renders order placement form and handles input', () => {
    render(<OrderPlacement />);
    
    const addressInput = screen.getByPlaceholderText(/Shipping Address/i);
    const phoneInput = screen.getByPlaceholderText(/Phone Number/i);

    fireEvent.change(addressInput, { target: { value: '123 Main St' } });
    fireEvent.change(phoneInput, { target: { value: '123-456-7890' } });

    expect(addressInput.value).toBe('123 Main St');
    expect(phoneInput.value).toBe('123-456-7890');
});
  
});
