package com.prjgrp.artf;

import com.prjgrp.artf.model.User;
import com.prjgrp.artf.model.Product;
import com.prjgrp.artf.model.Demand;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class ArtfApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;



    @Test
    public void testGetAllUsers() throws Exception {
        mockMvc.perform(get("/api/users"))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetUserById_NotFound() throws Exception {
        mockMvc.perform(get("/api/users/9999"))
                .andExpect(status().isNotFound());
    }

    @Test
    public void testCreateUser() throws Exception {
        User user = new User(null, "JohnDoe", "john@example.com");
        mockMvc.perform(post("/api/users")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(user)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username").value("JohnDoe"));
    }

    @Test
    public void testDeleteUser_NotFound() throws Exception {
        mockMvc.perform(delete("/api/users/9999"))
                .andExpect(status().isNotFound());
    }

    @Test
    public void testDeleteUser_Found() throws Exception {
        User user = new User(null, "JaneDoe", "jane@example.com");
        String userJson = objectMapper.writeValueAsString(user);
        mockMvc.perform(post("/api/users")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(userJson));

        mockMvc.perform(delete("/api/users/1"))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetAllUsers_CheckContent() throws Exception {
        mockMvc.perform(get("/api/users"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON));
    }



    @Test
    public void testGetAllDemands() throws Exception {
        mockMvc.perform(get("/api/demands"))
                .andExpect(status().isOk());
    }

    @Test
    public void testCreateDemand() throws Exception {
        Demand demand = new Demand(null, 1L, 1L, 10);
        mockMvc.perform(post("/api/demands")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(demand)))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetDemandById_NotFound() throws Exception {
        mockMvc.perform(get("/api/demands/9999"))
                .andExpect(status().isNotFound());
    }

    @Test
    public void testDeleteDemand_NotFound() throws Exception {
        mockMvc.perform(delete("/api/demands/9999"))
                .andExpect(status().isNotFound());
    }

    @Test
    public void testDeleteDemandById() throws Exception {
        Demand demand = new Demand(null, 1L, 1L, 10);
        String demandJson = objectMapper.writeValueAsString(demand);
        mockMvc.perform(post("/api/demands")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(demandJson));

        mockMvc.perform(delete("/api/demands/1"))
                .andExpect(status().isOk());
    }



    @Test
    public void testGetAllProducts() throws Exception {
        mockMvc.perform(get("/api/products"))
                .andExpect(status().isOk());
    }

    @Test
    public void testCreateProduct() throws Exception {
        Product product = new Product(null, "Laptop", "High-end laptop", 5, "Available");
        mockMvc.perform(post("/api/products")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(product)))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetProductById_NotFound() throws Exception {
        mockMvc.perform(get("/api/products/9999"))
                .andExpect(status().isNotFound());
    }

    @Test
    public void testDeleteProduct_NotFound() throws Exception {
        mockMvc.perform(delete("/api/products/9999"))
                .andExpect(status().isNotFound());
    }

    @Test
    public void testDeleteProductById() throws Exception {
        Product product = new Product(null, "Smartphone", "Latest model", 3, "Available");
        String productJson = objectMapper.writeValueAsString(product);
        mockMvc.perform(post("/api/products")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(productJson));

        mockMvc.perform(delete("/api/products/1"))
                .andExpect(status().isOk());
    }
}
